//
//  XLLoginPageView.h
//  pbuXingLianClient
//
//  Created by 1bu2bu on 2017/6/20.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XLLoginPageView : UIView

@end
