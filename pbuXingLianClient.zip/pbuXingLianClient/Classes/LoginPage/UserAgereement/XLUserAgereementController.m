//
//  XLUserAgereementController.m
//  Fitness
//
//  Created by 自知之明、 on 15/11/28.
//  Copyright © 2015年 自知之明、. All rights reserved.
//

#import "XLUserAgereementController.h"

@interface XLUserAgereementController ()

@end

@implementation XLUserAgereementController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self CreateHtml];
    // Do any additional setup after loading the view.
    m_pNameLabel.text = @"用户协议";
}

-(void)CreateHtml
{
    UIWebView *pUserWebView =[[UIWebView alloc] initWithFrame:CGRectMake(0, m_pTopBar.bottom, self.view.width, self.view.height - m_pTopBar.bottom)];
    NSString *path = [[NSBundle mainBundle]bundlePath];
    NSURL *pUserUrl = [NSURL fileURLWithPath:path];
    NSString *pHtmlPath = [[NSBundle mainBundle]pathForResource:@"userAgreement" ofType:@"html"];
    NSString *pHtmlCont = [NSString stringWithContentsOfFile:pHtmlPath
                                                    encoding:NSUTF8StringEncoding
                                                       error:nil];
    [self.view addSubview:pUserWebView];
    [pUserWebView loadHTMLString:pHtmlCont baseURL:pUserUrl];
    pUserWebView.clipsToBounds = NO;
}

-(void)BackView
{
    [self dismissViewControllerAnimated:YES completion:^{

    }];
}



-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    self.navigationController.navigationBar.hidden = YES;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
