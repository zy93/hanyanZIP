//
//  XLUserAgereementController.h
//  Fitness
//
//  Created by 自知之明、 on 15/11/28.
//  Copyright © 2015年 自知之明、. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BUCustomViewController.h"
//#import "XLPresentedController.h"

@interface XLUserAgereementController : BUCustomViewController

@end
