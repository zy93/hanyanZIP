//
//  XLForgotPasswordController.m
//  pbuXingLianClient
//
//  Created by 1bu2bu on 2017/7/17.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import "XLForgotPasswordController.h"
#import "XLForgotPasswordView.h"

@interface XLForgotPasswordController ()
{
    XLForgotPasswordView *m_pForgotPasswordView;
}
@end

@implementation XLForgotPasswordController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    m_pNameLabel.text = @"找回密码";
    [self CreateSubViews];
}

#pragma mark - private methods
-(void)CreateSubViews
{
    m_pForgotPasswordView = [[XLForgotPasswordView alloc] initWithFrame:CGRectMake(0, m_pTopBar.bottom, self.view.width, self.view.height - m_pTopBar.bottom)];
    [self.view addSubview:m_pForgotPasswordView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
