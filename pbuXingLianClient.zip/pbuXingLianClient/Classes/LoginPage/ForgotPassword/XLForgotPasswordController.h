//
//  XLForgotPasswordController.h
//  pbuXingLianClient
//
//  Created by 1bu2bu on 2017/7/17.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import "BUCustomViewController.h"

@interface XLForgotPasswordController : BUCustomViewController



@end
