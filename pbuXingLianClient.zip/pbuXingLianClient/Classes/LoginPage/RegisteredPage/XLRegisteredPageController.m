//
//  XLRegisteredPageController.m
//  pbuXingLianClient
//
//  Created by 1bu2bu on 2017/6/30.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import "XLRegisteredPageController.h"
#import "XLRegisteredPageView.h"
#import "XLSetUserInfoController.h"
#import "XLUserAgereementController.h"

@interface XLRegisteredPageController ()
{
    XLRegisteredPageView *m_pRegisteredView;
}
@end

@implementation XLRegisteredPageController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    m_pNameLabel.text = @"注册";
    self.view.backgroundColor = [AppConfigure MainBlackColor];
    [self CreateSubViews];
}
#pragma mark - private methods
-(void)CreateSubViews
{
    m_pRegisteredView = [[XLRegisteredPageView alloc] initWithFrame:CGRectMake(0, m_pTopBar.bottom, self.view.width, self.view.height - m_pTopBar.bottom)];
    [self.view addSubview:m_pRegisteredView];
}

#pragma mark -public methods
-(void)SetUserInfo
{
    XLSetUserInfoController *pSetUserInfoVC = [[XLSetUserInfoController alloc] init];
    [self PushChildViewController:pSetUserInfoVC];
}

-(void)CheckAgereement
{
    XLUserAgereementController *pUserAgreementVC = [[XLUserAgereementController alloc] init];
    [self PushChildViewController:pUserAgreementVC];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
