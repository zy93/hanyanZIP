//
//  XLRegisteredPageController.h
//  pbuXingLianClient
//
//  Created by 1bu2bu on 2017/6/30.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import "BUCustomViewController.h"

@interface XLRegisteredPageController : BUCustomViewController

-(void)SetUserInfo;

-(void)CheckAgereement;

@end
