//
//  XLRegisteredPageView.m
//  pbuXingLianClient
//
//  Created by 1bu2bu on 2017/6/30.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import "XLRegisteredPageView.h"
#import "BUCustomViewController.h"
#import "XLUserInfoData.h"
#import "NSStringExt.h"
#import "XLLoginMgr.h"
#import "XLRegisteredPageController.h"

#define TEXTFIELDTAG 1000
#define CODEBTNTAG 2008

@interface XLRegisteredPageView ()<UITextFieldDelegate,BUAFHttpRequestDelegate,XLLoginMgrDelegate>
{
    UIView *m_pHeadView;
    UIView *m_pBottomView;
    UIView *m_pPhoneView;
    UIView *m_pCodeView;
    UIView *m_pPasswordView;
    UIView *m_pInviteCodeView;
    UILabel *m_pAgreementLab;
    UIButton *m_pGetCodeBtn;
    NSString *m_strPhone;
    NSString *m_strPassword;
    
    NSInteger m_iTimeLength;
    NSTimer *m_pTimer;
    BUAFHttpRequest *m_pRegisteredRequest;
    BUAFHttpRequest *m_pGetCodeReqeust;
    
    BOOL m_bIsCode;
    
    UIButton *m_pRegisteredBtn;
}

@end

@implementation XLRegisteredPageView

-(id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        m_bIsCode = YES;
        m_strPhone = @"";
        m_strPassword = @"";
        [self CreateSubViews];
        [self CreateRequest];
    }
    return self;
}

#pragma mark - private methods

-(UIView *)CreateTextField:(CGPoint)argPoint andPrompt:(NSString *)argPrompt andPlaceholder:(NSString *)argPlaceholder andIsShowCode:(BOOL)argShow andTextFieldTag:(NSInteger)argTag andForSubView:(UIView *)argView;
{
    UIView *pView = [[UIView alloc] initWithFrame:CGRectMake(argPoint.x, argPoint.y,self.width , 60*[AppConfigure GetLengthAdaptRate])];
    pView.backgroundColor = [UIColor clearColor];
    
    UILabel *pPromptLab = [[UILabel alloc] initWithFrame:CGRectMake(10*[AppConfigure GetLengthAdaptRate], 0, 50, pView.height)];
    pPromptLab.text = argPrompt;
    pPromptLab.textColor = UIColorFromHex(0x333333);
    pPromptLab.font = [UIFont fontWithName:[AppConfigure RegularFont] size:16.0];
    pPromptLab.textAlignment = NSTextAlignmentCenter;
    pPromptLab.backgroundColor = [UIColor clearColor];
    [pView addSubview:pPromptLab];
    
    CGFloat fFieldY = (pView.height - 20) / 2.0;
    CGFloat fFieldW = pView.width - pPromptLab.right - 30*[AppConfigure GetLengthAdaptRate];
    if (argShow)
    {
        UIImage *pCodeImage = [UIImage imageNamed:@"phone_null.png"];
        CGFloat fCodeBtnY = (pView.height - pCodeImage.size.height)/2.0;
        fFieldW = fFieldW - 15*[AppConfigure GetLengthAdaptRate] - pCodeImage.size.width;
        
        m_pGetCodeBtn = [[UIButton alloc] initWithFrame:CGRectMake(pView.width - 10*[AppConfigure GetLengthAdaptRate] - pCodeImage.size.width, fCodeBtnY, pCodeImage.size.width, pCodeImage.size.height)];
        [m_pGetCodeBtn setTitle:@"发验证码" forState:UIControlStateNormal];
        [m_pGetCodeBtn setBackgroundImage:pCodeImage forState:UIControlStateNormal];
        m_pGetCodeBtn.titleLabel.font = [UIFont fontWithName:[AppConfigure RegularFont] size:13.0];
        m_pGetCodeBtn.tag = CODEBTNTAG;
        m_pGetCodeBtn.enabled = NO;
        [m_pGetCodeBtn addTarget:self action:@selector(GetCodeAction) forControlEvents:UIControlEventTouchUpInside];
        [pView addSubview:m_pGetCodeBtn];
    }
    UITextField *pTextField = [[UITextField alloc] initWithFrame:CGRectMake(pPromptLab.right + 15*[AppConfigure GetLengthAdaptRate], fFieldY, fFieldW, 20)];
    pTextField.tag = TEXTFIELDTAG + argTag;
    pTextField.placeholder = argPlaceholder;
    pTextField.delegate = self;
    pTextField.font = [UIFont fontWithName:[AppConfigure RegularFont] size:16.0];
    pTextField.textColor = UIColorFromHex(0x333333);
    pTextField.returnKeyType = UIReturnKeyDone;
    pTextField.backgroundColor = [UIColor clearColor];
    UIColor *pPlaceholderColor = UIColorFromHex(0xaaaaaa);
    pTextField.attributedPlaceholder = [[NSAttributedString alloc] initWithString:pTextField.placeholder attributes:@{NSForegroundColorAttributeName: pPlaceholderColor}];
    [pView addSubview:pTextField];
    if (argTag == 0)
    {
        [pTextField addTarget:self action:@selector(TextFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
        pTextField.keyboardType = UIKeyboardTypeNumberPad;
    }else if (argTag == 2)
    {
         [pTextField setSecureTextEntry:YES];
//        pTextField.keyboardType = UIKeyboardTypeNumberPad;
    }else if (argTag == 1)
    {
        pTextField.keyboardType = UIKeyboardTypeNumberPad;
    }

    UIView *pLineView = [[UIView alloc] initWithFrame:CGRectMake(0, pPromptLab.bottom , pView.width , 0.5)];
    pLineView.backgroundColor = UIColorFromHex(0xdddddd);
    [pView addSubview:pLineView];
    
    [argView addSubview:pView];
    return pView;
}
-(void)CreateSubViews
{
    m_pHeadView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.width, 180*[AppConfigure GetLengthAdaptRate])];
    m_pHeadView.backgroundColor = [UIColor whiteColor];
    [self addSubview:m_pHeadView];
    
    m_pPhoneView = [self CreateTextField:CGPointMake(0, 0) andPrompt:@"手机号" andPlaceholder:@"请输入手机号" andIsShowCode:YES andTextFieldTag:0  andForSubView:m_pHeadView];
    m_pCodeView = [self CreateTextField:CGPointMake(0, m_pPhoneView.bottom) andPrompt:@"验证码" andPlaceholder:@"请输入验证码" andIsShowCode:NO andTextFieldTag:1  andForSubView:m_pHeadView];
    m_pPasswordView = [self CreateTextField:CGPointMake(0, m_pCodeView.bottom) andPrompt:@"新密码" andPlaceholder:@"请输入密码" andIsShowCode:NO andTextFieldTag:2  andForSubView:m_pHeadView];
    
    m_pBottomView = [[UIView alloc] initWithFrame:CGRectMake(0, m_pHeadView.bottom + 8*[AppConfigure GetLengthAdaptRate], self.width, self.height - m_pHeadView.height - 10*[AppConfigure GetLengthAdaptRate])];
    m_pBottomView.backgroundColor = [UIColor whiteColor];
    [self addSubview:m_pBottomView];
    
    m_pInviteCodeView = [self CreateTextField:CGPointMake(0, 0) andPrompt:@"邀请码" andPlaceholder:@"如果您有邀请码，请输入邀请码" andIsShowCode:NO andTextFieldTag:3  andForSubView:m_pBottomView];
    
    
    
    // 下划线
 
    
    m_pAgreementLab = [[UILabel alloc] initWithFrame:CGRectMake(10*[AppConfigure GetLengthAdaptRate], m_pInviteCodeView.bottom + 20*[AppConfigure GetLengthAdaptRate], m_pBottomView.width - 20*[AppConfigure GetLengthAdaptRate], 14)];
    m_pAgreementLab.text = @"点击注册，表示您已阅读且同意“星炼用户协议”";
    m_pAgreementLab.textColor = UIColorFromHex(0x666666);
    m_pAgreementLab.font = [UIFont fontWithName:[AppConfigure RegularFont] size:13.0];
    m_pAgreementLab.userInteractionEnabled = YES;
    [m_pBottomView addSubview:m_pAgreementLab];

    NSMutableAttributedString *attribtStr = [[NSMutableAttributedString alloc]initWithString:m_pAgreementLab.text];
    [attribtStr addAttribute:NSUnderlineStyleAttributeName value:[NSNumber numberWithInteger:NSUnderlineStyleSingle] range:NSMakeRange(15, 6)];
    //赋值
    m_pAgreementLab.attributedText = attribtStr;
    
    UIButton *pAgreementBtn = [[UIButton alloc] initWithFrame:m_pAgreementLab.bounds];
    [pAgreementBtn addTarget:self action:@selector(CheckAgreement) forControlEvents:UIControlEventTouchUpInside];
    [m_pAgreementLab addSubview:pAgreementBtn];
    
    
    UIImage *pLoninImg = [UIImage imageNamed:@"login_confirm.png"];
    CGFloat fRegisteredBtnX = (self.width - pLoninImg.size.width ) / 2.0;
    UIButton *pRegisteredBtn = [[UIButton alloc] initWithFrame:CGRectMake(fRegisteredBtnX, m_pAgreementLab.bottom + 60 *[AppConfigure GetLengthAdaptRate], pLoninImg.size.width, pLoninImg.size.height)];
    [pRegisteredBtn setBackgroundImage:pLoninImg forState:UIControlStateNormal];
    [pRegisteredBtn setTitle:@"注册" forState:UIControlStateNormal];
    pRegisteredBtn.titleEdgeInsets = UIEdgeInsetsMake(-5*[AppConfigure GetLengthAdaptRate], 0, 0, 0);
    pRegisteredBtn.titleLabel.font = [UIFont fontWithName:[AppConfigure RegularFont] size:18.0];
    pRegisteredBtn.titleLabel.textAlignment = NSTextAlignmentCenter;
    [pRegisteredBtn addTarget:self action:@selector(Registered) forControlEvents:UIControlEventTouchUpInside];
    [m_pBottomView addSubview:pRegisteredBtn];
}
-(void)CheckAgreement
{
    [((XLRegisteredPageController *)[self GetSubordinateControllerForSelf]) CheckAgereement];
}

-(void)CreateRequest
{
    m_pRegisteredRequest = [[BUAFHttpRequest alloc] initWithUrl:@"register.php" andTag:@"register"];
    m_pRegisteredRequest.propDelegate = self;
    m_pRegisteredRequest.propDataClass = [XLUserInfoData class];
    
    m_pGetCodeReqeust = [[BUAFHttpRequest alloc] initWithUrl:@"captcha.php" andTag:@"captcha"];
    m_pGetCodeReqeust.propDelegate = self;
    m_pGetCodeReqeust.propDataClass = [XLUserInfoData class];
    [m_pGetCodeReqeust SetParamValue:@"1" forKey:@"type"];
}


- (void)GetCodeAction
{
    UITextField *pPhoneFiled = [m_pHeadView viewWithTag:TEXTFIELDTAG];
    UITextField *pCodeFiled = [m_pHeadView viewWithTag:TEXTFIELDTAG+1];
    [pPhoneFiled resignFirstResponder];
    [pCodeFiled becomeFirstResponder];
    if (IS_EMPTY_STRING(pPhoneFiled.text))
    {
        [((XLRegisteredPageController *)[self GetSubordinateControllerForSelf]) ShowHUDWithMessage:@"请输入你的手机号"];
        return;
    }
    if (![pPhoneFiled.text isValidPhoneNumber] || pPhoneFiled.text.length != 11)
    {
        [((XLRegisteredPageController *)[self GetSubordinateControllerForSelf]) ShowHUDWithMessage:@"请输入正确的手机号"];
        return;
    }
    [m_pGetCodeReqeust SetParamValue:pPhoneFiled.text forKey:@"mobile"];
    [m_pGetCodeReqeust PostAsynchronous];

    m_iTimeLength = 60;
    [self CountdownAction];
    m_bIsCode = NO;
    m_pTimer = [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(CountdownAction) userInfo:nil repeats:YES];
}

/**
 *  倒计时事件
 */
- (void)CountdownAction
{
    m_pGetCodeBtn.userInteractionEnabled = NO;
    if (m_iTimeLength > 0)
    {
        [m_pGetCodeBtn setBackgroundImage:[UIImage imageNamed:@"phone_null.png"] forState:UIControlStateNormal];
        [m_pGetCodeBtn setTitle:[NSString  stringWithFormat:@"%lis",(long)m_iTimeLength] forState:UIControlStateNormal];
    }
    else if (m_iTimeLength <= 0)
    {
        m_pGetCodeBtn.userInteractionEnabled = YES;
        m_bIsCode = YES;
        [m_pGetCodeBtn setTitle:@"发验证码" forState:UIControlStateNormal];
        [m_pGetCodeBtn setBackgroundImage:[UIImage imageNamed:@"phone_noNull.png"] forState:UIControlStateNormal];
        [(XLRegisteredPageController *)[self GetSubordinateControllerForSelf] ShowHUDWithMessage:@"正在加载...."];
        [self TimeDealloc];
    }
    -- m_iTimeLength;
}

- (void)TimeDealloc
{
    [m_pTimer invalidate];
    m_pTimer = nil;
}

-(void)Registered
{
    UITextField *pPhoneFiled = [m_pHeadView viewWithTag:TEXTFIELDTAG];
    UITextField *pCodeFiled = [m_pHeadView viewWithTag:TEXTFIELDTAG+1];
    UITextField *pPasswordFiled = [m_pHeadView viewWithTag:TEXTFIELDTAG+2];
    UITextField *pInviteCodeFiled = [m_pBottomView viewWithTag:TEXTFIELDTAG+3];
    if (IS_EMPTY_STRING(pPhoneFiled.text))
    {
        [((XLRegisteredPageController *)[self GetSubordinateControllerForSelf]) ShowHUDWithMessage:@"请输入你的手机号"];
        return;
    }
    if (![pPhoneFiled.text isValidPhoneNumber] || pPhoneFiled.text.length != 11)
    {
        [((XLRegisteredPageController *)[self GetSubordinateControllerForSelf]) ShowHUDWithMessage:@"请输入正确的手机号"];
        return;
    }
    if (IS_EMPTY_STRING(pCodeFiled.text))
    {
        [((XLRegisteredPageController *)[self GetSubordinateControllerForSelf]) ShowHUDWithMessage:@"请输入你的验证码"];
        return;
    }
    if (IS_EMPTY_STRING(pPasswordFiled.text))
    {
        [((XLRegisteredPageController *)[self GetSubordinateControllerForSelf]) ShowHUDWithMessage:@"请输入你的密码"];
        return;
    }
    
    if (pPasswordFiled.text.length < 6 || pPasswordFiled.text.length > 12)
    {
        [(XLRegisteredPageController*) [self GetSubordinateControllerForSelf]  ShowHUDWithMessage:@"密码长度6-12个字符，请重新输入"];
        return ;
    }
    m_strPhone = pPhoneFiled.text;
    m_strPassword = pPasswordFiled.text;
    [m_pRegisteredRequest SetParamValue:pPhoneFiled.text forKey:@"mobile"];
    [m_pRegisteredRequest SetParamValue:pCodeFiled.text forKey:@"captcha"];
    [m_pRegisteredRequest SetParamValue:pPasswordFiled.text forKey:@"password"];
    if (!IS_EMPTY_STRING(pPasswordFiled.text))
    {
        [m_pRegisteredRequest SetParamValue:pInviteCodeFiled.text forKey:@"inviteCode"];
    }
    [m_pRegisteredRequest PostAsynchronous];
    m_pRegisteredBtn.userInteractionEnabled = NO;
    [(XLRegisteredPageController *)[self GetSubordinateControllerForSelf] ShowHUDWithMessage:@"正在加载...."];
}

-(void)TextFieldDidChange:(UITextField *)argTextField
{
    if (argTextField.text.length > 0 && m_bIsCode)
    {
        m_pGetCodeBtn.userInteractionEnabled = YES;
        m_pGetCodeBtn.enabled = YES;
        [m_pGetCodeBtn setTitle:@"发验证码" forState:UIControlStateNormal];
        [m_pGetCodeBtn setBackgroundImage:[UIImage imageNamed:@"phone_noNull.png"] forState:UIControlStateNormal];
    }else if (argTextField.text.length <= 0)
    {
        m_pGetCodeBtn.userInteractionEnabled = NO;
        [self TimeDealloc];
        m_bIsCode = YES;
        m_pGetCodeBtn.enabled = NO;
        [m_pGetCodeBtn setTitle:@"发验证码" forState:UIControlStateNormal];
        [m_pGetCodeBtn setBackgroundImage:[UIImage imageNamed:@"phone_null.png"] forState:UIControlStateNormal];
    }
}

#pragma mark - BUAFHttpRequestDelegate methods
-(void)RequestSucceeded:(NSString *)argRequestTag withResponseData:(NSArray *)argData
{
    if ([argRequestTag isEqualToString:@"captcha"])
    {
        [self HideProgressHUD];
    }
    
    if ([argRequestTag isEqualToString:@"register"])
    {
        [self HideProgressHUD];
        m_pRegisteredBtn.userInteractionEnabled = NO;
        [XLLoginMgr sharedXLLoginMgr].propDelegate = self;
        [[XLLoginMgr sharedXLLoginMgr] LoginRequest:m_strPhone andPassword:m_strPassword andType:2];
    }
}
- (void)RequestErrorHappened:(BUAFHttpRequest *)argRequest withErrorMsg:(NSString *)argMsg
{
    m_pGetCodeBtn.userInteractionEnabled = NO;
    [self TimeDealloc];
    m_bIsCode = YES;
    m_pGetCodeBtn.enabled = NO;
    [m_pGetCodeBtn setTitle:@"发验证码" forState:UIControlStateNormal];
    [m_pGetCodeBtn setBackgroundImage:[UIImage imageNamed:@"phone_null.png"] forState:UIControlStateNormal];
    [(XLRegisteredPageController *)[self GetSubordinateControllerForSelf] ShowHUDWithMessage:argMsg];
}

- (void)RequestFailed:(BUAFHttpRequest *)argRequest
{
    [self HideProgressHUD];
}

-(void)HideProgressHUD
{
    [(XLRegisteredPageController *)[self GetSubordinateControllerForSelf] HideProgressHUD];
}

#pragma mark - XLLoginMgrDelegate methods
-(void)LoginSuccessful
{
    [[NSNotificationCenter defaultCenter] postNotificationName:kLoginSucceedNotifity object:nil];
    [(XLRegisteredPageController *)[self GetSubordinateControllerForSelf] SetUserInfo];
    [self HideProgressHUD];
}
-(void)LoginFailure
{
    m_pRegisteredBtn.userInteractionEnabled = YES;
    [self HideProgressHUD];
}


@end
