
//
//  XLLoginPageView.m
//  pbuXingLianClient
//
//  Created by 1bu2bu on 2017/6/20.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import "XLLoginPageView.h"
#import "XLLoginPageController.h"
#import "XLLoginMgr.h"
//融云
#import <RongIMKit/RongIMKit.h>


@interface XLLoginPageView ()<UITextFieldDelegate,XLLoginMgrDelegate>
{
    UITextField *m_pPhoneField;
    UITextField *m_pPasswordField;
    UIButton *m_pRegisteredBtn;
    UIView *m_pThirdView;
}

@end

@implementation XLLoginPageView

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor = [UIColor whiteColor];
        [self CreateSubViews];
    }
    return self;
}

#pragma mark - private methods
-(void)CreateSubViews
{
    UIImage *pCloseImg = [UIImage imageNamed:@"close.png"];
    UIButton *pCloseBtn = [[UIButton alloc] initWithFrame:CGRectMake(self.width - 20*[AppConfigure GetLengthAdaptRate] - 40 , 33*[AppConfigure GetLengthAdaptRate], 40, 40)];
    [pCloseBtn setImage:pCloseImg forState:UIControlStateNormal];
    [pCloseBtn addTarget:self action:@selector(Back) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:pCloseBtn];
    
    UIImage *pLogoImg = [UIImage imageNamed:@"login_logo.png"];
    CGFloat fLogoViewX = (self.width - pLogoImg.size.width) / 2.0;
    UIImageView *pLogoView = [[UIImageView alloc] initWithFrame:CGRectMake(fLogoViewX, 80*[AppConfigure GetLengthAdaptRate], pLogoImg.size.width, pLogoImg.size.height)];
    pLogoView.image = pLogoImg;
    pLogoView.layer.cornerRadius = 10.0f;
    pLogoView.layer.masksToBounds = YES;
    [self addSubview:pLogoView];
    
    UILabel *pTitleLab = [[UILabel alloc] initWithFrame:CGRectMake(0, pLogoView.bottom + 15*[AppConfigure GetLengthAdaptRate], self.width, 20)];
    pTitleLab.text = @"星炼";
    pTitleLab.textAlignment = NSTextAlignmentCenter;
    pTitleLab.textColor = UIColorFromHex(0x333333);
    pTitleLab.font = [UIFont fontWithName:[AppConfigure RegularFont] size:18.0];
    [self addSubview:pTitleLab];
    
    UILabel *pPhoneLab = [[UILabel alloc] initWithFrame:CGRectMake(45*[AppConfigure GetLengthAdaptRate], pTitleLab.bottom + 53*[AppConfigure GetLengthAdaptRate], 30, 16)];
    pPhoneLab.text = @"手机号";
    pPhoneLab.textColor = UIColorFromHex(0x333333);
    pPhoneLab.font = [UIFont fontWithName:[AppConfigure RegularFont] size:16.0];
    [self addSubview:pPhoneLab];
    [pPhoneLab sizeToFit];
    
    CGFloat fPhoneFieldW = self.width - 85*[AppConfigure GetLengthAdaptRate] - pPhoneLab.width;
    m_pPhoneField = [[UITextField alloc] initWithFrame:CGRectMake(pPhoneLab.right + 15*[AppConfigure GetLengthAdaptRate], pPhoneLab.top, fPhoneFieldW, pPhoneLab.height)];
    m_pPhoneField.placeholder = @"请输入手机号码";
    m_pPhoneField.delegate = self;
    m_pPhoneField.text = @"18700000001";
    m_pPhoneField.font = [UIFont fontWithName:[AppConfigure RegularFont] size:16.0];
    m_pPhoneField.returnKeyType = UIReturnKeyDone;
    m_pPhoneField.keyboardType = UIKeyboardTypeNumberPad;
    [self addSubview:m_pPhoneField];
    
    UIView *pLineView = [[UIView alloc] initWithFrame:CGRectMake(35*[AppConfigure GetLengthAdaptRate], m_pPhoneField.bottom + 17*[AppConfigure GetLengthAdaptRate], self.width - 70*[AppConfigure GetLengthAdaptRate], 0.5)];
    pLineView.backgroundColor = UIColorFromHex(0xdddddd);
    [self addSubview:pLineView];
    
    UILabel *pPasswordLab = [[UILabel alloc] initWithFrame:CGRectMake(45*[AppConfigure GetLengthAdaptRate], pLineView.bottom + 29*[AppConfigure GetLengthAdaptRate], 30, 16)];
    pPasswordLab.text = @"密码";
    pPasswordLab.textColor = UIColorFromHex(0x333333);
    pPasswordLab.font = [UIFont fontWithName:[AppConfigure RegularFont] size:16.0];
    [self addSubview:pPasswordLab];
    [pPasswordLab sizeToFit];
    
    CGFloat fPasswordFieldW = self.width - pPasswordLab.width;
    m_pPasswordField = [[UITextField alloc] initWithFrame:CGRectMake(pPasswordLab.right + 15*[AppConfigure GetLengthAdaptRate], pPasswordLab.top, fPasswordFieldW, pPasswordLab.height)];
    m_pPasswordField.placeholder = @"请输入密码";
    m_pPasswordField.text = @"123456";
    m_pPasswordField.delegate = self;
    m_pPasswordField.secureTextEntry=YES;//密文
    m_pPasswordField.font = [UIFont fontWithName:[AppConfigure RegularFont] size:16.0];
    m_pPasswordField.returnKeyType = UIReturnKeyDone;
    [self addSubview:m_pPasswordField];
    

    UIView *pLineView1 = [[UIView alloc] initWithFrame:CGRectMake(35*[AppConfigure GetLengthAdaptRate], m_pPasswordField.bottom + 17*[AppConfigure GetLengthAdaptRate], self.width - 70*[AppConfigure GetLengthAdaptRate], 0.5)];
    pLineView1.backgroundColor = UIColorFromHex(0xdddddd);
    [self addSubview:pLineView1];
    
    UIButton *pForgotPasswordBtn = [[UIButton alloc] initWithFrame:CGRectMake(40*[AppConfigure GetLengthAdaptRate] , pLineView1.bottom + 30*[AppConfigure GetLengthAdaptRate], 70, 15)];
    [pForgotPasswordBtn setTitle:@"忘记密码？" forState:UIControlStateNormal];
    pForgotPasswordBtn.titleLabel.font = [UIFont fontWithName:[AppConfigure RegularFont] size:14.0];
    [pForgotPasswordBtn setTitleColor:UIColorFromHex(0x333333) forState:UIControlStateNormal];
    [pForgotPasswordBtn addTarget:self action:@selector(ForgotPassword) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:pForgotPasswordBtn];
    
    m_pRegisteredBtn = [[UIButton alloc] initWithFrame:CGRectMake(self.width - 40*[AppConfigure GetLengthAdaptRate] - 56, pLineView1.bottom + 30*[AppConfigure GetLengthAdaptRate], 56, 15)];
    [m_pRegisteredBtn setTitle:@"手机注册" forState:UIControlStateNormal];
    [m_pRegisteredBtn setTitleColor:UIColorFromHex(0x333333) forState:UIControlStateNormal];
    m_pRegisteredBtn.titleLabel.font = [UIFont fontWithName:[AppConfigure RegularFont] size:14.0];
    [m_pRegisteredBtn addTarget:self action:@selector(Registered) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:m_pRegisteredBtn];
    
    
    UIImage *pLoninImg = [UIImage imageNamed:@"login_confirm.png"];
    CGFloat fLoginBtnX = (self.width - pLoninImg.size.width ) / 2.0;
    UIButton *pLoginBtn = [[UIButton alloc] initWithFrame:CGRectMake(fLoginBtnX, pLineView1.bottom + 75 *[AppConfigure GetLengthAdaptRate], pLoninImg.size.width, pLoninImg.size.height)];
    [pLoginBtn setBackgroundImage:pLoninImg forState:UIControlStateNormal];
    [pLoginBtn setTitle:@"登录" forState:UIControlStateNormal];
    pLoginBtn.titleEdgeInsets = UIEdgeInsetsMake(-5*[AppConfigure GetLengthAdaptRate], 0, 0, 0);
    pLoginBtn.titleLabel.font = [UIFont fontWithName:[AppConfigure RegularFont] size:18.0];
    pLoginBtn.titleLabel.textAlignment = NSTextAlignmentCenter;
    [pLoginBtn addTarget:self action:@selector(Login) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:pLoginBtn];
    
    m_pThirdView = [[UIView alloc] initWithFrame:CGRectMake(0, pLoginBtn.bottom, self.width, self.height - pLoginBtn.bottom)];
    m_pThirdView.backgroundColor = [UIColor whiteColor];
    [self addSubview:m_pThirdView];
    
    UILabel *pThirdLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 20*[AppConfigure GetLengthAdaptRate], m_pThirdView.width, 13)];
    pThirdLab.text = @"第三方登录";
    pThirdLab.font = [UIFont fontWithName:[AppConfigure RegularFont] size:12];
    pThirdLab.textColor = UIColorFromHex(0xaaaaaa);
    [m_pThirdView addSubview:pThirdLab];
    [pThirdLab sizeToFit];
    pThirdLab.frame = CGRectMake(0, pThirdLab.top, pThirdLab.width, 13);
    pThirdLab.center = CGPointMake(m_pThirdView.center.x, pThirdLab.center.y);
    
    CGFloat fLineViewW = (m_pThirdView.width - pThirdLab.width - 46*[AppConfigure GetLengthAdaptRate])/2.0;
    UIView *pLine1 = [[UIView alloc] initWithFrame:CGRectMake(15*[AppConfigure GetLengthAdaptRate], 0, fLineViewW, 0.5)];
    pLine1.backgroundColor = UIColorFromHex(0xe6e6e6);
    pLine1.center = CGPointMake(pLine1.center.x, pThirdLab.center.y);
    [m_pThirdView addSubview:pLine1];
    
    UIView *pLine2 = [[UIView alloc] initWithFrame:CGRectMake(pThirdLab.right +8*[AppConfigure GetLengthAdaptRate], 0, fLineViewW, 0.5)];
    pLine2.backgroundColor = UIColorFromHex(0xe6e6e6);
    pLine2.center = CGPointMake(pLine2.center.x, pThirdLab.center.y);
    [m_pThirdView addSubview:pLine2];

    UIImage *pWxImg = [UIImage imageNamed:@"login_weixin.png"];
    UIImage *pWbImg = [UIImage imageNamed:@"login_weibo.png"];
    
    CGFloat fBtnX = (m_pThirdView.width - pWxImg.size.width - pWbImg.size.width - 80*[AppConfigure GetLengthAdaptRate])/2.0;
    
    UIButton *pWxBtn = [[UIButton alloc] initWithFrame:CGRectMake(fBtnX, pThirdLab.bottom + 25*[AppConfigure GetLengthAdaptRate], pWxImg.size.width, pWxImg.size.height)];
    [pWxBtn setBackgroundImage:pWxImg forState:UIControlStateNormal];
    [pWxBtn addTarget:self action:@selector(WxLogin) forControlEvents:UIControlEventTouchUpInside];
    [m_pThirdView addSubview:pWxBtn];
    
    UIButton *pWbBtn = [[UIButton alloc] initWithFrame:CGRectMake(pWxBtn.right + 80*[AppConfigure GetLengthAdaptRate], pThirdLab.bottom + 25*[AppConfigure GetLengthAdaptRate], pWbImg.size.width, pWbImg.size.height)];
    [pWbBtn setBackgroundImage:pWbImg forState:UIControlStateNormal];
    [pWbBtn addTarget:self action:@selector(WbLogin) forControlEvents:UIControlEventTouchUpInside];
    [m_pThirdView addSubview:pWbBtn];
    
}

-(void)Back
{
    dispatch_async(dispatch_get_main_queue(), ^{
        
        [[self GetSubordinateControllerForSelf].navigationController dismissViewControllerAnimated:YES completion:^{
        }];
    });
}

-(void)ForgotPassword
{
    [(XLLoginPageController *)[self GetSubordinateControllerForSelf] EnterForgotPasswordView];
}

-(void)WxLogin
{
    NSLog(@"wx");
//    if (![WXApi isWXAppInstalled])
//    {
//        [(XLLoginPageController *)[self GetSubordinateControllerForSelf] ShowHUDWithMessage:@"您的手机未安装微信，请选择其它登录方式"];
//        return;
//    }
    [XLLoginMgr sharedXLLoginMgr].propDelegate = self;
    [(XLLoginPageController *)[self GetSubordinateControllerForSelf] WxLogin];

}



-(void)WbLogin
{
    NSLog(@"sina");
    [XLLoginMgr sharedXLLoginMgr].propDelegate = self;
    [(XLLoginPageController *)[self GetSubordinateControllerForSelf] WbLogin];
}

-(void)Login
{
    NSString *pPhone = m_pPhoneField.text;
    NSString *pPassword = m_pPasswordField.text;
    if ([pPhone isEqualToString:@""])
    {
        [self ShowAlertMessga:@"请输入手机号"];
    }else if (pPhone.length != 11)
    {
        [self ShowAlertMessga:@"请输入正确的手机号"];
    }else if ([pPassword isEqualToString:@""])
    {
        [self ShowAlertMessga:@"请输入密码"];
    }else if (pPassword.length < 6 && pPassword.length >= 13)
    {
        [(BUCustomViewController*) [self GetSubordinateControllerForSelf]  ShowHUDWithMessage:@"密码长度6-12个字符，请重新输入"];
        return ;
    }else
    {
        [XLLoginMgr sharedXLLoginMgr].propDelegate = self;
        [[XLLoginMgr sharedXLLoginMgr] LoginRequest:pPhone andPassword:pPassword andType:1];
        [(XLLoginPageController *)[self GetSubordinateControllerForSelf] ShowProgressHUDWithMessage:@"正在加载...."];
    }
}

-(void)Registered
{
    [(XLLoginPageController *)[self GetSubordinateControllerForSelf] EnterRegisteredView];
}

-(void)ShowAlertMessga:(NSString *)argMsg
{
    [self ShowAlertWithMessage:argMsg SuccessBlock:^(NSInteger buttonIndex)
    {
        NSLog(@"buttonIndex");
    }];
}

-(void)HideProgressHUD
{
    [(XLLoginPageController *)[self GetSubordinateControllerForSelf] HideProgressHUD];
}

#pragma mark - XLLoginMgrDelegate methods
-(void)LoginSuccessful
{
    [[NSNotificationCenter defaultCenter] postNotificationName:kLoginSucceedNotifity object:nil];
    [self HideProgressHUD];
    [self Back];
}

-(void)LoginFailure
{
    [[RCIM sharedRCIM] disconnect:NO];
    [XLLoginMgr sharedXLLoginMgr].propUserData = nil;
    [XLLoginMgr sharedXLLoginMgr].propUserData.token = @"4bed7fc0f334eb97bbf6b94c142d2538";
    [XLLoginMgr sharedXLLoginMgr].propIsLogin = 0;
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:nil forKey:@"userData"];
    [defaults setObject:@"0" forKey:@"isLogin"];
    [defaults synchronize];
    [self HideProgressHUD];
    [self ShowAlertMessga:@"登录失败，请检查您的账号以及密码是否正确"];
}

@end
