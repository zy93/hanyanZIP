//
//  XLLoginPageController.h
//  pbuXingLianClient
//
//  Created by 1bu2bu on 2017/6/20.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import "BUCustomViewController.h"
//#import "XLPresentedController.h"

@interface XLLoginPageController : BUCustomViewController

-(void)WxLogin;

-(void)WbLogin;

-(void)EnterRegisteredView;

-(void)EnterForgotPasswordView;

@end
