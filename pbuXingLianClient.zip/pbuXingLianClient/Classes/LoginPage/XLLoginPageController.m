//
//  XLLoginPageController.m
//  pbuXingLianClient
//
//  Created by 1bu2bu on 2017/6/20.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import "XLLoginPageController.h"
#import "XLLoginPageView.h"
#import "XLRegisteredPageController.h"
#import "XLForgotPasswordController.h"

#define kRedirectURI @"https://api.weibo.com/oauth2/default.html"
@interface XLLoginPageController ()
{
    XLLoginPageView *m_pLoginView;
}
@end

@implementation XLLoginPageController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    if( iPhoneX)
    {
        CGRect frame = self.view.frame;
        frame.origin.y = 34;
        frame.size.height = [[UIScreen mainScreen] bounds].size.height-34-34;
        self.view.frame = frame;
    
    }
    
    m_pTopBar.hidden = YES;
    [self CreateSubViews];
}

#pragma mark - private mthods
-(void)CreateSubViews
{
    m_pLoginView = [[XLLoginPageView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview:m_pLoginView];
}

#pragma mark - public metods
-(void)EnterRegisteredView
{
    XLRegisteredPageController *pRegisteredVC = [[XLRegisteredPageController alloc] init];
    [self PushChildViewController:pRegisteredVC];
}

-(void)EnterForgotPasswordView
{
    XLForgotPasswordController *pForgotPasswordVC = [[XLForgotPasswordController alloc] init];
    [self PushChildViewController:pForgotPasswordVC];
}

-(void)WxLogin
{
    NSLog(@"111");

}

-(void)WbLogin
{
    NSLog(@"111");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




@end
