//
//  XLSerUserInfoView.m
//  pbuXingLianClient
//
//  Created by 1bu2bu on 2017/7/3.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import "XLSetUserInfoView.h"
#import "XLImageWordButton.h"
#import "XLSetUserInfoController.h"

#define TEXTFIELDTAG

@interface XLSetUserInfoView ()<UITextFieldDelegate>
{
    UIView *m_pTopView;
    UIImageView *m_pHeadIconView;
    UITextField *m_pNickNameField;
    UIView *m_pBottomView;
    UIView *m_pNickNameView;
    UIView *m_pGenderView;
    UIView *m_pCityView;
    XLImageWordButton *m_pManBtn;
    XLImageWordButton *m_pWomanBtn;
    UILabel *m_pCityLab;
    NSInteger m_iGender;                            //性别 1男 2女
}

@end

@implementation XLSetUserInfoView

-(id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        m_iGender = -1;
        [self CreateSubViews];
    }
    return self;
}

#pragma mark - private methods

-(UIView *)CreateTextField:(CGPoint)argPoint andPrompt:(NSString *)argPrompt andPlaceholder:(NSString *)argPlaceholder andIsShowCode:(BOOL)argShow andTextFieldTag:(NSInteger)argTag andForSubView:(UIView *)argView;
{
    UIView *pView = [[UIView alloc] initWithFrame:CGRectMake(argPoint.x, argPoint.y,self.width , 60*[AppConfigure GetLengthAdaptRate])];
    pView.backgroundColor = [UIColor clearColor];
    
    UILabel *pPromptLab = [[UILabel alloc] initWithFrame:CGRectMake(10*[AppConfigure GetLengthAdaptRate], 0, 65, pView.height)];
    pPromptLab.text = argPrompt;
    pPromptLab.textColor = UIColorFromHex(0x333333);
    pPromptLab.font = [UIFont fontWithName:[AppConfigure RegularFont] size:16.0];
    pPromptLab.textAlignment = NSTextAlignmentLeft;
    pPromptLab.backgroundColor = [UIColor clearColor];
    [pView addSubview:pPromptLab];
    
    CGFloat fFieldY = (pView.height - 20) / 2.0;
    CGFloat fFieldW = pView.width - pPromptLab.right - 25*[AppConfigure GetLengthAdaptRate];
    if (argTag == 0)
    {
        m_pNickNameField = [[UITextField alloc] initWithFrame:CGRectMake(pPromptLab.right + 15*[AppConfigure GetLengthAdaptRate], fFieldY, fFieldW, 20)];
        m_pNickNameField.tag = TEXTFIELDTAG + argTag;
        m_pNickNameField.placeholder = argPlaceholder;
        m_pNickNameField.delegate = self;
        m_pNickNameField.font = [UIFont fontWithName:[AppConfigure RegularFont] size:16.0];
        m_pNickNameField.textColor = UIColorFromHex(0x333333);
        m_pNickNameField.returnKeyType = UIReturnKeyDone;
        m_pNickNameField.backgroundColor = [UIColor clearColor];
        UIColor *pPlaceholderColor = UIColorFromHex(0xaaaaaa);
        m_pNickNameField.textAlignment = NSTextAlignmentRight;
        m_pNickNameField.attributedPlaceholder = [[NSAttributedString alloc] initWithString:m_pNickNameField.placeholder attributes:@{NSForegroundColorAttributeName: pPlaceholderColor}];
        [pView addSubview:m_pNickNameField];
    }else if (argTag == 1)
    {
        UIImage *pNoSelectImg = [UIImage imageNamed:@"gender_noSelect.png"];
        UIImage *pSelectImage = [UIImage imageNamed:@"gender_select.png"];
        CGFloat fButtonW = 40*[AppConfigure GetLengthAdaptRate];
        CGFloat fButtonY = (pView.height - pNoSelectImg.size.width)/2.0;
        CGFloat fButtonX = pView.width - fButtonW*2 - 30*[AppConfigure GetLengthAdaptRate];
        m_pManBtn = [[XLImageWordButton alloc] initWithFrame:CGRectMake(fButtonX, fButtonY, fButtonW, pNoSelectImg.size.height)];
        [m_pManBtn setImage:pNoSelectImg forState:UIControlStateNormal];
        [m_pManBtn setImage:pSelectImage forState:UIControlStateSelected];
        [m_pManBtn setTitleColor:UIColorFromHex(0x999999) forState:UIControlStateNormal];
        [m_pManBtn setTitle:@"男" forState:UIControlStateNormal];
        [m_pManBtn addTarget:self action:@selector(SelectGender:) forControlEvents:UIControlEventTouchUpInside];
        [pView addSubview:m_pManBtn];
        
        m_pWomanBtn = [[XLImageWordButton alloc] initWithFrame:CGRectMake(m_pManBtn.right + 20*[AppConfigure GetLengthAdaptRate], fButtonY, fButtonW, pNoSelectImg.size.height)];
        [m_pWomanBtn setImage:pNoSelectImg forState:UIControlStateNormal];
        [m_pWomanBtn setImage:pSelectImage forState:UIControlStateSelected];
        [m_pWomanBtn setTitleColor:UIColorFromHex(0x999999) forState:UIControlStateNormal];
        [m_pWomanBtn setTitle:@"女" forState:UIControlStateNormal];
        [m_pWomanBtn addTarget:self action:@selector(SelectGender:) forControlEvents:UIControlEventTouchUpInside];
        [pView addSubview:m_pWomanBtn];
    }else if (argTag == 2)
    {
        UIImage *pSelectImg = [UIImage imageNamed:@"more.png"];
        CGFloat fSelectViewY = (pView.height - pSelectImg.size.height )/2.0;
        UIImageView *pSelectView = [[UIImageView alloc] initWithFrame:CGRectMake(pView.width - 10*[AppConfigure GetLengthAdaptRate], fSelectViewY, pSelectImg.size.width, pSelectImg.size.height)];
        pSelectView.image = pSelectImg;
        [pView addSubview:pSelectView];
        
        CGFloat fCityLabW = pView.width - pPromptLab.width - pSelectView.size.width - 30*[AppConfigure GetLengthAdaptRate];
        m_pCityLab = [[UILabel alloc] initWithFrame:CGRectMake(pPromptLab.right + 10*[AppConfigure GetLengthAdaptRate], 0, fCityLabW, pView.height)];
        m_pCityLab.text = @"请选择所在省市";
        m_pCityLab.textColor = UIColorFromHex(0xaaaaaa);
        m_pCityLab.font = [UIFont fontWithName:[AppConfigure RegularFont] size:16.0];
        m_pCityLab.textAlignment = NSTextAlignmentRight;
        m_pCityLab.userInteractionEnabled = YES;
        [pView addSubview:m_pCityLab];
        
        UIButton *pCityBtn = [[UIButton alloc] initWithFrame:m_pCityLab.bounds];
        [pCityBtn addTarget:self action:@selector(SelectCity) forControlEvents:UIControlEventTouchUpInside];
        [m_pCityLab addSubview:pCityBtn];
    }
    
    UIView *pLineView = [[UIView alloc] initWithFrame:CGRectMake(0, pPromptLab.bottom , pView.width , 0.5)];
    pLineView.backgroundColor = UIColorFromHex(0xdddddd);
    [pView addSubview:pLineView];
    
    [argView addSubview:pView];
    return pView;
}

-(void)CreateSubViews
{
    m_pTopView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.width, 190*[AppConfigure GetLengthAdaptRate])];
    m_pTopView.backgroundColor = [UIColor blackColor];
    [self addSubview:m_pTopView];
    
    UIImage *pCloseBtnImg = [UIImage imageNamed:@"skip.png"];
    UIButton *pCloseBtn = [[UIButton alloc] initWithFrame:CGRectMake(m_pTopView.width - pCloseBtnImg.size.width - 10*[AppConfigure GetLengthAdaptRate], 28*[AppConfigure GetLengthAdaptRate], pCloseBtnImg.size.width, pCloseBtnImg.size.height)];
    [pCloseBtn setBackgroundImage:pCloseBtnImg forState:UIControlStateNormal];
    [pCloseBtn addTarget:self action:@selector(SkipSet) forControlEvents:UIControlEventTouchUpInside];
    [m_pTopView addSubview:pCloseBtn];
    
    UIImage *pHedIconImg = [UIImage imageNamed:@"set_headIcon.png"];
    CGFloat fHeadIconX = (m_pTopView.width - pHedIconImg.size.width)/2.0;
    m_pHeadIconView = [[UIImageView alloc] initWithFrame:CGRectMake(fHeadIconX, 55*[AppConfigure GetLengthAdaptRate], pHedIconImg.size.width, pHedIconImg.size.height)];
    m_pHeadIconView.image = pHedIconImg;
    m_pHeadIconView.userInteractionEnabled = YES;
    m_pHeadIconView.layer.cornerRadius = m_pHeadIconView.height / 2.0;
    m_pHeadIconView.layer.masksToBounds = YES;
    [m_pTopView addSubview:m_pHeadIconView];
    
    UIButton *pHeadIconBtn = [[UIButton alloc] initWithFrame:m_pHeadIconView.bounds];
    [pHeadIconBtn addTarget:self action:@selector(SelectHeadIcon) forControlEvents:UIControlEventTouchUpInside];
    [m_pHeadIconView addSubview:pHeadIconBtn];
    
    UILabel *pTitleLab = [[UILabel alloc] initWithFrame:CGRectMake(0, m_pHeadIconView.bottom + 16*[AppConfigure GetLengthAdaptRate], m_pTopView.width , 16)];
    pTitleLab.text = @"设置头像";
    pTitleLab.textColor = UIColorFromHex(0x999999);
    pTitleLab.font = [UIFont fontWithName:[AppConfigure RegularFont] size:15.0];
    pTitleLab.textAlignment = NSTextAlignmentCenter;
    [m_pTopView addSubview:pTitleLab];
    
    m_pBottomView = [[UIView alloc] initWithFrame:CGRectMake(0, m_pTopView.bottom, self.width, self.height - m_pTopView.bottom)];
    m_pBottomView.backgroundColor = [UIColor whiteColor];
    [self addSubview:m_pBottomView];
    
    m_pNickNameView = [self CreateTextField:CGPointMake(0, 0) andPrompt:@"昵称" andPlaceholder:@"请输入昵称" andIsShowCode:NO andTextFieldTag:0 andForSubView:m_pBottomView];
    
    m_pGenderView = [self CreateTextField:CGPointMake(0, m_pNickNameView.bottom) andPrompt:@"性别" andPlaceholder:@"" andIsShowCode:YES andTextFieldTag:1 andForSubView:m_pBottomView];
    
    m_pCityView = [self CreateTextField:CGPointMake(0, m_pGenderView.bottom) andPrompt:@"所在省份" andPlaceholder:@"请选择省份" andIsShowCode:NO andTextFieldTag:2 andForSubView:m_pBottomView];
    
    
    UIImage *pLoninImg = [UIImage imageNamed:@"login_confirm.png"];
    CGFloat fLoginBtnX = (self.width - pLoninImg.size.width ) / 2.0;
    UIButton *pLoginBtn = [[UIButton alloc] initWithFrame:CGRectMake(fLoginBtnX, m_pCityView.bottom + 58 *[AppConfigure GetLengthAdaptRate], pLoninImg.size.width, pLoninImg.size.height)];
    [pLoginBtn setBackgroundImage:pLoninImg forState:UIControlStateNormal];
    [pLoginBtn setTitle:@"确定" forState:UIControlStateNormal];
    pLoginBtn.titleEdgeInsets = UIEdgeInsetsMake(-5*[AppConfigure GetLengthAdaptRate], 0, 0, 0);
    pLoginBtn.titleLabel.font = [UIFont fontWithName:[AppConfigure RegularFont] size:18.0];
    pLoginBtn.titleLabel.textAlignment = NSTextAlignmentCenter;
    [pLoginBtn addTarget:self action:@selector(ConfirmUploadUserInfo) forControlEvents:UIControlEventTouchUpInside];
    [m_pBottomView addSubview:pLoginBtn];
}

-(void)SkipSet
{
    [(XLSetUserInfoController *)[self GetSubordinateControllerForSelf] SkipSet];
}

-(void)SelectHeadIcon
{
    [(XLSetUserInfoController *)[self GetSubordinateControllerForSelf] SelectHeadIcon];
}

-(void)SelectGender:(UIButton *)argBtn
{
    if (argBtn == m_pManBtn)
    {
        m_pManBtn.selected = YES;
        m_pWomanBtn.selected = NO;
        m_iGender = 1;
    }else if (argBtn == m_pWomanBtn)
    {
        m_pManBtn.selected = NO;
        m_pWomanBtn.selected = YES;
        m_iGender = 2;
    }
}

-(void)SelectCity
{
    [(XLSetUserInfoController *)[self GetSubordinateControllerForSelf] SelectCity];
}

-(void)ConfirmUploadUserInfo
{
    [(XLSetUserInfoController *)[self GetSubordinateControllerForSelf] UploadUserInfo:m_pNickNameField.text andGender:m_iGender];
}

#pragma mark - public methods

-(void)SetHeadIcon:(UIImage *)argHeadIcon;
{
    m_pHeadIconView.image = argHeadIcon;
}

-(void)SetCityName:(NSString *)argCity
{
    m_pCityLab.text = argCity;
}

@end
