//
//  XLSerUserInfoView.h
//  pbuXingLianClient
//
//  Created by 1bu2bu on 2017/7/3.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XLSetUserInfoView : UIView

-(void)SetHeadIcon:(UIImage *)argHeadIcon;

-(void)SetCityName:(NSString *)argCity;



@end
