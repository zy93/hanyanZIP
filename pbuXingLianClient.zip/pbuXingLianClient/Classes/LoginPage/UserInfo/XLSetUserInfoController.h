//
//  XLSetUserInfoController.h
//  pbuXingLianClient
//
//  Created by 1bu2bu on 2017/7/3.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import "BUCustomViewController.h"


@interface XLSetUserInfoController : BUCustomViewController

-(void)SelectHeadIcon;

-(void)SelectCity;

-(void)UploadUserInfo:(NSString *)argNickName andGender:(NSInteger)argGender;

-(void)SkipSet;

@end
