//
//  XLCityListCell.h
//  Fitness
//
//  Created by Xue Yan on 16/7/6.
//  Copyright © 2016年 Xue Yan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XLCityListCell : UITableViewCell

-(void)SetCity:(NSString *)argCity;

@end
