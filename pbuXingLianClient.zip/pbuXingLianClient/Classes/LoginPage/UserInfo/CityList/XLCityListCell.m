//
//  XLCityListCell.m
//  Fitness
//
//  Created by Xue Yan on 16/7/6.
//  Copyright © 2016年 Xue Yan. All rights reserved.
//

#import "XLCityListCell.h"

@interface XLCityListCell ()
{
    UIView *m_pBackView;
    UILabel *m_pCityLab;
}
@end

@implementation XLCityListCell

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        self.contentView.backgroundColor = [AppConfigure MainBlackColor];
        [self CreateSubViews];
    }
    return self;
}

#pragma mark - private methods
-(void)CreateSubViews
{
    m_pBackView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 64*[AppConfigure GetLengthAdaptRate])];
    m_pBackView.backgroundColor = [UIColor whiteColor];
    [self.contentView addSubview:m_pBackView];
    
    m_pCityLab = [[UILabel alloc] initWithFrame:CGRectMake(10*[AppConfigure GetLengthAdaptRate], 0, m_pBackView.width - 20*[AppConfigure GetLengthAdaptRate], 64*[AppConfigure GetLengthAdaptRate])];
    m_pCityLab.text = @"北京市";
    m_pCityLab.font = [UIFont fontWithName:[AppConfigure RegularFont] size:15.0];
    m_pCityLab.textColor = UIColorFromHex(0x333333);
    [m_pBackView addSubview:m_pCityLab];
    
}

-(void)SetCity:(NSString *)argCity
{
    m_pCityLab.text = argCity;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
