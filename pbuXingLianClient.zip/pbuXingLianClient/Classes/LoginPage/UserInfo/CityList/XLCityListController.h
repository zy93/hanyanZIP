//
//  XLCityListController.h
//  Fitness
//
//  Created by Xue Yan on 16/7/6.
//  Copyright © 2016年 Xue Yan. All rights reserved.
//

#import "BUCustomViewController.h"

@protocol XLCityListControllerDelegate <NSObject>

-(void)SelectCity:(NSString *)argCity;

@end

@interface XLCityListController : BUCustomViewController

@property(nonatomic,weak)id<XLCityListControllerDelegate> propDelegate;

@end
