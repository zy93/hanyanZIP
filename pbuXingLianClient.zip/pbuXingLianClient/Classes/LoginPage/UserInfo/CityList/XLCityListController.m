//
//  XLCityListController.m
//  Fitness
//
//  Created by Xue Yan on 16/7/6.
//  Copyright © 2016年 Xue Yan. All rights reserved.
//

#import "XLCityListController.h"
#import "XLCityListCell.h"

@interface XLCityListController ()<UITableViewDelegate,UITableViewDataSource>
{
    UITableView *m_pTableView;
    NSMutableArray *m_arrCity;
}

@end

@implementation XLCityListController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [AppConfigure MainBlackColor];
    m_pNameLabel.text = @"选择城市";
    m_arrCity = [NSMutableArray array];
    [self CreateSubViews];
    [self CreateDataSource];
}


#pragma mark - private methods
-(void)CreateSubViews
{
    m_pTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, m_pTopBar.bottom, self.view.width, self.view.height - m_pTopBar.bottom)];
    m_pTableView.dataSource = self;
    m_pTableView.delegate = self;
    m_pTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    m_pTableView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:m_pTableView];
}

-(void)CreateDataSource
{
    m_arrCity = [[NSMutableArray alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"ProvincesAndCities.plist" ofType:nil]];
    if (m_arrCity.count != 0)
    {
        [m_pTableView reloadData];
    }
}
#pragma mark - UITableView Delegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return m_arrCity.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return  64*[AppConfigure GetLengthAdaptRate] + 1;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"XLCityListCell";
    XLCityListCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil)
    {
        cell = [[XLCityListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    [cell SetCity:[m_arrCity[indexPath.row] objectForKey:@"State"]];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.propDelegate != nil && [self.propDelegate respondsToSelector:@selector(SelectCity:)])
    {
        [self.propDelegate SelectCity:[m_arrCity[indexPath.row] objectForKey:@"State"]];
    }
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
