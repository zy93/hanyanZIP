//
//  XLSetUserInfoController.m
//  pbuXingLianClient
//
//  Created by 1bu2bu on 2017/7/3.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import "XLSetUserInfoController.h"
#import "XLSetUserInfoView.h"
#import "EIImagePickerDelegate.h"
#import "TSImageEditorView.h"
#import "UIImage+Cut.h"
#import "XLCityListController.h"
#import "XLLoginMgr.h"
#import "NSString+IntValue.h"
#import "AFAliyunOssServer.h"

@interface XLSetUserInfoController ()<TSImageEditorViewDelegate,XLCityListControllerDelegate>
{
    XLSetUserInfoView *m_pSetUserInfoVIew;
    EIImagePickerDelegate* m_pImagePicker;
    BUAFHttpRequest *m_pSetUserInfoRequest;
    NSString *m_strChangeCity;
    UIImage *m_pChangeImage;
}
@end

@implementation XLSetUserInfoController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    m_pTopBar.hidden = YES;
    m_strChangeCity = @"";
    [self CreateSubViews];
    [self CreateRequest];
}

#pragma mark - private methods
-(void)SkipSet
{
    [self.navigationController dismissViewControllerAnimated:YES completion:^{
    }];
}

-(void)CreateSubViews
{
    m_pSetUserInfoVIew = [[XLSetUserInfoView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview:m_pSetUserInfoVIew];
}

-(void)CreateRequest
{
    m_pSetUserInfoRequest = [[BUAFHttpRequest alloc] initWithUrl:@"modifyUserInfo.php" andTag:@"modifyUserInfo"];
    m_pSetUserInfoRequest.propDelegate = self;
    m_pSetUserInfoRequest.propDataClass = [XLUserInfoData class];
    [m_pSetUserInfoRequest SetParamValue:[XLLoginMgr sharedXLLoginMgr].propUserData.uid forKey:@"uid"];
    [m_pSetUserInfoRequest SetParamValue:[XLLoginMgr sharedXLLoginMgr].propUserData.token forKey:@"token"];
}

#pragma mark - public methods

-(void)SelectHeadIcon
{
    m_pImagePicker = [[EIImagePickerDelegate alloc] init];
    [m_pImagePicker presentFromController:self withSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    __weak XLSetUserInfoController *weakSelf = self;
    [m_pImagePicker setImagePickerCompletionBlock:^(UIImage* pickerImage)
     {
         TSImageEditorView *pImageEditorV = [[TSImageEditorView alloc]initWithFrame:weakSelf.view.bounds andImage:pickerImage];
         pImageEditorV.proDelegate = weakSelf;
         [weakSelf.view addSubview:pImageEditorV];
     }];
}

-(void)SelectCity
{
    XLCityListController *pCityListVC = [[XLCityListController alloc] init];
    pCityListVC.propDelegate = self;
    [self PushChildViewController:pCityListVC];
}

-(void)UploadUserInfo:(NSString *)argNickName andGender:(NSInteger)argGender
{
    if (argNickName != nil && ![argNickName isEqualToString:@""])
    {
        [XLLoginMgr sharedXLLoginMgr].propUserData.userName = argNickName;
        [m_pSetUserInfoRequest SetParamValue:argNickName forKey:@"nickName"];
    }
    if (argGender != -1)
    {
        [XLLoginMgr sharedXLLoginMgr].propUserData.gender = [NSString IntergerString:argGender];
        [m_pSetUserInfoRequest SetParamValue:[NSString IntergerString:argGender] forKey:@"gender"];
    }
    if (m_strChangeCity != nil && ![m_strChangeCity isEqualToString:@""])
    {
        [XLLoginMgr sharedXLLoginMgr].propUserData.city = m_strChangeCity;
        [m_pSetUserInfoRequest SetParamValue:m_strChangeCity forKey:@"city"];
    }
    if (m_pChangeImage != nil)
    {
        [AFAliyunOssServer uploadImage:m_pChangeImage progress:^(int64_t bytesSent, int64_t totalBytesSent, int64_t totalBytesExpectedToSend)
        {
            NSLog(@"不知道是干嘛的");
        } success:^(NSString *url)
        {
            NSLog(@"%@",url);
            [XLLoginMgr sharedXLLoginMgr].propUserData.headIcon = url;
            [m_pSetUserInfoRequest SetParamValue:url forKey:@"headIcon"];
            [m_pSetUserInfoRequest PostAsynchronous];
        } failure:^{
            NSLog(@"上传失败了。");
        }];
    }else
    {
        NSLog(@"没有图片");
        [m_pSetUserInfoRequest PostAsynchronous];
    }

}



#pragma mark - XLCityListControllerDelegate methods
-(void)SelectCity:(NSString *)argCity
{
    m_strChangeCity = argCity;
    [m_pSetUserInfoVIew SetCityName:argCity];
}
#pragma mark -- TSImageEditorViewDelegate method
- (void)TSImageEditorFinishedEditingImage:(UIImage *)argImage
{
    m_pChangeImage = argImage;
    [m_pSetUserInfoVIew SetHeadIcon:m_pChangeImage];
    [m_pImagePicker dismissViewControllerAnimated:YES completion:^{
    }];
}

#pragma mark - BUAFHttpRequestDelegate methods
-(void)RequestSucceeded:(NSString *)argRequestTag withResponseData:(NSArray *)argData
{
    if ([argRequestTag isEqualToString:@"modifyUserInfo"])
    {
        NSData *pData = [NSKeyedArchiver archivedDataWithRootObject:[XLLoginMgr sharedXLLoginMgr].propUserData];
 
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        [defaults setObject:pData forKey:@"userData"];
        [defaults setObject:@"1" forKey:@"isLogin"];
        [defaults synchronize];
        [self SkipSet];
    }
}
- (void)RequestErrorHappened:(BUAFHttpRequest *)argRequest withErrorMsg:(NSString *)argMsg
{
    [self ShowProgressHUDWithMessage:argMsg];
    [self RequestFailed:argRequest];
}

- (void)RequestFailed:(BUAFHttpRequest *)argRequest
{
    [self HideProgressHUD];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
