//
//  XLGuideViewController.m
//  Fitness
//
//  Created by Xue Yan on 15/10/26.
//  Copyright © 2015年 Xue Yan. All rights reserved.
//

#import "XLGuideViewController.h"
#import <MediaPlayer/MediaPlayer.h>

@interface XLGuideViewController ()
{
    MPMoviePlayerController *m_pVideoPler;
    UIView *m_pBackView;
    UIButton *m_pEnterBtn;
    UIImageView *m_pEnterImgView;
}

@end

@implementation XLGuideViewController

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault];
    self.navigationController.navigationBar.hidden = YES;
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    // Do any additional setup after loading the view.
    m_pTopBar.hidden = YES;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(VideoEndPlay) name:MPMoviePlayerPlaybackDidFinishNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(VideoState:) name:MPMoviePlayerLoadStateDidChangeNotification object:m_pVideoPler];
    
    [self makeLunchView];
    
}

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}

- (void)makeLunchView
{
    m_pBackView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.width, self.view.height)];
    m_pBackView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:m_pBackView];
    
    NSBundle *pBundle = [NSBundle mainBundle];
    NSString *pMoviePath = [pBundle pathForResource:@"appGuide" ofType:@"mp4"];
    NSLog(@"pMoviePath%@",pMoviePath);
    NSURL *pMovieURL = [NSURL fileURLWithPath:pMoviePath];
    
    m_pVideoPler = [[MPMoviePlayerController alloc] initWithContentURL:pMovieURL];
    m_pVideoPler.controlStyle = MPMovieControlStyleNone;     ///隐藏进度条
    m_pVideoPler.repeatMode = MPMovieRepeatModeNone;      ///重复播放
    m_pVideoPler.shouldAutoplay = NO;
    m_pVideoPler.fullscreen = YES;
    m_pVideoPler.scalingMode = MPMovieScalingModeAspectFill;     ///播放比例
    m_pVideoPler.view.hidden = YES;
    [m_pBackView addSubview:m_pVideoPler.view];
    m_pVideoPler.view.frame = CGRectMake(0, 0, self.view.width, self.view.height);
    m_pVideoPler.view.backgroundColor = [UIColor whiteColor];
    [m_pVideoPler play];
//    [m_pVideoPler setCurrentPlaybackTime:2];
    
    m_pEnterBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    m_pEnterBtn.frame = CGRectMake(0, 0, self.view.frame.size.width,self.view.frame.size.height);
    m_pEnterBtn.backgroundColor = [UIColor clearColor];
    m_pEnterBtn.hidden = YES;
    [m_pEnterBtn addTarget:self action:@selector(EnterToLog) forControlEvents:UIControlEventTouchUpInside];
    [m_pBackView addSubview:m_pEnterBtn];
    
    UIImage *pEnterImg = [UIImage imageNamed:@"enterPage.png"];
    CGFloat fImageX = (self.view.width - pEnterImg.size.width)/2;
    m_pEnterImgView = [[UIImageView alloc] initWithFrame:CGRectMake(fImageX, self.view.height - 75*[AppConfigure GetLengthAdaptRate] - pEnterImg.size.height, pEnterImg.size.width, pEnterImg.size.height)];
    m_pEnterImgView.image = pEnterImg;
    m_pEnterImgView.hidden = YES;
    m_pEnterImgView.alpha = 0;
    [m_pBackView addSubview:m_pEnterImgView];
}

-(void)VideoEndPlay
{
    __weak UIImageView *pWeakSelf = m_pEnterImgView;
    [UIView animateWithDuration:0.3
                     animations:^{
                         pWeakSelf.alpha = 1;
                         pWeakSelf.hidden = NO;
                     }
                     completion:^(BOOL finished) {
                         
                     }];
    m_pEnterBtn.hidden = NO;
}

-(void)VideoState:(NSNotification *)argNotif
{
    NSLog(@"播放状态:%li",(long)m_pVideoPler.loadState);
    if (m_pVideoPler.loadState == 3)
    {
        m_pVideoPler.view.hidden = NO;
        [m_pVideoPler play];
    }
}


-(void)EnterToLog
{
    [mAppDelegate EnterMainPage];
    [mUserDefaults setObject:@(1) forKey:@"NotFirstLauch"];
    [mUserDefaults synchronize];
}


-(UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleDefault;
}

-(BOOL)prefersStatusBarHidden
{
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
