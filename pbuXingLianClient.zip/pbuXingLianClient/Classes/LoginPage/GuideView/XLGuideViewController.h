//
//  XLGuideViewController.h
//  Fitness
//
//  Created by Xue Yan on 15/10/26.
//  Copyright © 2015年 Xue Yan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "BUCustomViewController.h"

@protocol XLGUideViewControllerDelegate <NSObject>

-(void)PicButtonClick;

@end

@interface XLGuideViewController : BUCustomViewController<UIScrollViewDelegate>
{
    UIPageControl *_page;
    UIScrollView *_scr;
}

@property(nonatomic, weak)id<XLGUideViewControllerDelegate> propDelegate;

@end
