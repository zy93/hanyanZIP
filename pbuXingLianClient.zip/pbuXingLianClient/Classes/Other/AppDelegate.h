//
//  AppDelegate.h
//  pbuXingLianClient
//
//  Created by 1bu2bu on 2017/6/20.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (assign, nonatomic) BOOL shouldChangeOrientation;

/**
 *  进入到登录页面
 */
- (void)EnterLoginPage;

/**
 *  进入主页面
 */
- (void)EnterMainPage;

- (void)HiddetnTabBar;



@end

