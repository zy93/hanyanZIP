//
//  RCDTableViewController.h
//  SealTalk
//
//  Created by Sin on 2017/9/26.
//  Copyright © 2017年 RongCloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RCDTableViewController : UITableViewController

@end
