//
//  XLPresentedController.m
//  pbuXingLianClientUITests
//
//  Created by Ruixin Wang on 2017/12/9.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import "XLPresentedController.h"

@interface XLPresentedController ()

@end

@implementation XLPresentedController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    if( iPhoneX)
    {
        CGRect frame = self.view.frame;
        frame.origin.y = 34;
        frame.size.height = [[UIScreen mainScreen] bounds].size.height-34-34;
        self.view.frame = frame;
        
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewDidLayoutSubviews
{
    if(iPhoneX)
    {
        CGRect frame = self.view.frame;
        frame.origin.y = 34;
        frame.size.height = [[UIScreen mainScreen] bounds].size.height-34-34;
        self.view.frame = frame;
    }
}

@end
