//
//  XLChatController.m
//  pbuXingLianClient
//
//  Created by 1bu2bu on 2017/12/11.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import "XLChatController.h"
#import <RongIMKit/RCChatSessionInputBarControl.h>
#import <RongIMKit/RCConversationModel.h>
#import <RongIMKit/RCEmojiBoardView.h>
#import <RongIMKit/RCMessageBaseCell.h>
#import <RongIMKit/RCMessageModel.h>
#import <RongIMKit/RCPluginBoardView.h>
#import <RongIMKit/RCThemeDefine.h>
#import <UIKit/UIKit.h>

@interface XLChatController ()

@end

@implementation XLChatController
    
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    if( iPhoneX)
    {
        CGRect frame = self.view.frame;
        frame.origin.y = 34;
        frame.size.height = [[UIScreen mainScreen] bounds].size.height-34-34;
        self.view.frame = frame;
        
        self.conversationMessageCollectionView.frame = CGRectMake(self.conversationMessageCollectionView.left, self.conversationMessageCollectionView.top, self.conversationMessageCollectionView.width, self.view.height - self.chatSessionInputBarControl.height);
        
        self.chatSessionInputBarControl.frame = CGRectMake(self.chatSessionInputBarControl.left, self.view.height - self.chatSessionInputBarControl.height, self.chatSessionInputBarControl.width, self.chatSessionInputBarControl.height);
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
    
-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    if(iPhoneX)
    {
        CGRect frame = self.view.frame;
        frame.origin.y = 34;
        frame.size.height = [[UIScreen mainScreen] bounds].size.height-34-34;
        self.view.frame = frame;
        
        self.conversationMessageCollectionView.frame = CGRectMake(self.conversationMessageCollectionView.left, self.conversationMessageCollectionView.top, self.conversationMessageCollectionView.width, self.view.height - self.chatSessionInputBarControl.height);
        
        self.chatSessionInputBarControl.frame = CGRectMake(self.chatSessionInputBarControl.left, self.view.height - self.chatSessionInputBarControl.height, self.chatSessionInputBarControl.width, self.chatSessionInputBarControl.height);
    }
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
