//
//  XLPresentedController.h
//  pbuXingLianClientUITests
//
//  Created by Ruixin Wang on 2017/12/9.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import "BUCustomViewController.h"

@interface XLPresentedController : BUCustomViewController

@end
