//
//  XLImageWordButton.m
//  pbuXingLianClient
//
//  Created by 1bu2bu on 2017/6/28.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import "XLImageWordButton.h"

@implementation XLImageWordButton

-(id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        [self CreateSubViews];
    }
    return self;
}

#pragma mark - private methods
-(void)CreateSubViews
{
    self.titleLabel.font = [UIFont fontWithName:[AppConfigure RegularFont] size:14.0];
    [self setTitleColor:UIColorFromHex(0x999999) forState:UIControlStateNormal];
    [self setImageEdgeInsets:UIEdgeInsetsMake(0, -10*[AppConfigure GetLengthAdaptRate], 0, 0)];
}

@end
