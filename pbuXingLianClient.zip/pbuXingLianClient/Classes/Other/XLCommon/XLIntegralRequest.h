//
//  XLIntegralRequest.h
//  pbuXingLianClient
//
//  Created by 1bu2bu on 2017/12/8.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol XLIntegralRequestDelegate <NSObject>

-(void)RequestSuccess:(NSInteger)argStatus;

@end
@interface XLIntegralRequest : NSObject

@property (nonatomic,weak)id<XLIntegralRequestDelegate> propDeleagte;

-(id)initWithType:(NSInteger)argType;

-(void)LaunchRequest;

@end
