//
//  XLTypeButton.h
//  pbuXingLianClient
//
//  Created by Yee on 2017/7/5.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef NS_ENUM(NSUInteger, XLTypeButtonEdgeInsetsStyle)
{
     XLTypeButtonImageLeft,
     XLTypeButtonImageRight,
     XLTypeButtonImageTop,
     XLTypeButtonImageBottom
};
IB_DESIGNABLE
@interface XLTypeButton : UIButton
#if TARGET_INTERFACE_BUILDER
@property (nonatomic) IBInspectable NSUInteger edgeInsetsStyle;
#else
@property (nonatomic) XLTypeButtonEdgeInsetsStyle edgeInsetsStyle;
#endif
@property (nonatomic) IBInspectable CGFloat imageTitleSpace;



@end

