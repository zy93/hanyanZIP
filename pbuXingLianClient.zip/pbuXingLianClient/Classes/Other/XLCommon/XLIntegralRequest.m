//
//  XLIntegralRequest.m
//  pbuXingLianClient
//
//  Created by 1bu2bu on 2017/12/8.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import "XLIntegralRequest.h"
#import "BUAFHttpRequest.h"
#import "XLLoginMgr.h"
#import "XLMineJiFenData.h"

@interface XLIntegralRequest ()<BUAFHttpRequestDelegate>
{
    XLMineJiFenData *m_pData;
    BUAFHttpRequest *m_pRequest;
}
@end

@implementation XLIntegralRequest

-(id)initWithType:(NSInteger)argType
{
    self = [super init];
    if (self)
    {
        [self CreateRequest];
    }
    return self;
}

#pragma mmark - private methods
-(void)CreateRequest
{
    m_pRequest = [[BUAFHttpRequest alloc] initWithUrl:@"" andTag:@""];
    [m_pRequest SetParamValue:[XLLoginMgr sharedXLLoginMgr].propUserData.uid forKey:@"uid"];
    [m_pRequest SetParamValue:[XLLoginMgr sharedXLLoginMgr].propUserData.token forKey:@"uid"];
    [m_pRequest SetParamValue:@"6" forKey:@"type"];
    m_pRequest.propDelegate = self;
    m_pRequest.propDataClass = [XLMineJiFenData class];
}

#pragma mark - public methods
-(void)LaunchRequest
{
    [m_pRequest PostAsynchronous];
}

#pragma mark - BUAFHttpRequestDelegate methods
-(void)RequestSucceeded:(NSString *)argRequestTag withResponseData:(NSArray *)argData
{
    if ([argRequestTag isEqualToString:@"starLiveAllRequest"])
    {
        m_pData = [argData firstObject];
        if (self.propDeleagte != nil && [self.propDeleagte respondsToSelector:@selector(RequestSuccess:)])
        {
            [self.propDeleagte RequestSuccess:m_pData.status];
        }
    }
}
- (void)RequestErrorHappened:(BUAFHttpRequest *)argRequest withErrorMsg:(NSString *)argMsg
{
    [self RequestFailed:argRequest];
}

- (void)RequestFailed:(BUAFHttpRequest *)argRequest
{
    NSLog(@"请求失败");
}

@end
