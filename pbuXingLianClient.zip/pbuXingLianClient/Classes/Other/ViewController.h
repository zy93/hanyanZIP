//
//  ViewController.h
//  pbuXingLianClient
//
//  Created by 1bu2bu on 2017/6/20.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BUCustomViewController.h"

@interface ViewController : BUCustomViewController


@end

