//
//  ViewController.m
//  pbuXingLianClient
//
//  Created by 1bu2bu on 2017/6/20.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import "ViewController.h"
#import "XLLoginMgr.h"
#import "BUCustomViewController.h"
#import <RongIMKit/RongIMKit.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    m_pNameLabel.text = @"测试";
    [self CreateSubViews];
}
//IM需要现实NavigationBar 但是其他页需要隐藏
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES];
    // self.navigationController.interactivePopGestureRecognizer.delegate=self;
}

#pragma mark - private methods
-(void)CreateSubViews
{
    UIButton *pPostChatBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 200, 40)];
    [pPostChatBtn setTitle:@"发起聊天" forState:UIControlStateNormal];
    pPostChatBtn.titleLabel.font = [UIFont fontWithName:[AppConfigure RegularFont] size:15.0];
    pPostChatBtn.center = CGPointMake(self.view.center.x, self.view.center.y);
    [pPostChatBtn addTarget:self action:@selector(PostChat) forControlEvents:UIControlEventTouchUpInside];
    [pPostChatBtn setBackgroundColor:UIColorFromHex(0x1792d4)];
    [self.view addSubview:pPostChatBtn];
}

-(void)PostChat
{
    if ([XLLoginMgr sharedXLLoginMgr].propIsLogin == 1)
    {
        [mAppDelegate HiddetnTabBar];
        //新建一个聊天会话View Controller对象,建议这样初始化
        RCConversationViewController *chat = [[RCConversationViewController alloc] initWithConversationType:ConversationType_PRIVATE targetId:@"3"];
        //设置聊天会话界面要显示的标题
        chat.title = @"丞磊";
        //是否显示发送人昵称
        chat.displayUserNameInCell = NO;
        //显示聊天会话界面
        [RCIM sharedRCIM].enableMessageAttachUserInfo = YES;
        RCUserInfo *user = [[RCUserInfo alloc] initWithUserId:@"3"
                                                         name:@"丞磊"
                                                     portrait:@"http://xinglian3.oss-cn-beijing.aliyuncs.com/users/15087491484147.jpg"];
        //        [[RCDataBaseManager shareInstance] insertUserToDB:user];
        [[RCIM sharedRCIM] refreshUserInfoCache:user withUserId:@"3"];
        
        UINavigationController * pNavController = [[self.view GetSubordinateControllerForSelf] navigationController];
        [pNavController pushViewController:chat animated:YES];
        pNavController.interactivePopGestureRecognizer.delegate=nil;
        [pNavController setNavigationBarHidden:NO];
    }else
    {
        [mAppDelegate EnterLoginPage];
    }
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
