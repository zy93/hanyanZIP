//
//  XLUserInfoData.h
//  pbuXingLianClient
//
//  Created by 1bu2bu on 2017/6/20.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import "AFBaseModuleData.h"

@interface XLUserInfoData : AFBaseModuleData

@property (nonatomic,copy)NSString *uid;

@property (nonatomic,copy)NSString *token;

@property (nonatomic,copy)NSString *nickname;

@property (nonatomic,copy)NSString *userName;

@property (nonatomic,copy)NSString *headIcon;

@property (nonatomic,copy)NSString *content;

@property (nonatomic,copy)NSString *isLogin;

@property (nonatomic,copy)NSString *city;

@property (nonatomic,copy)NSString *gender; //性别1 男 2 女

@property (nonatomic,copy)NSString *result;                   //用户提交的答案

@property (nonatomic,copy)NSString *isFollow;

@property (nonatomic,copy)NSString *yuntoken;                 //融云token

@property (nonatomic,copy)NSString *loginType;                  

//content = "\U674e\U56db\U674e\U56db\U674e\U56db\U674e\U56db\U674e\U56db\U674e\U56db";
//gender = 2;
//hasHtmlIntr = 2;
//headIcon = "http://guoanchuangke.oss-cn-beijing.aliyuncs.com/image147011559377-16042Q4395Y23.jpg";
//isFollow = 0;
//liveId = 56;
//userName = "\U674e\U56db";
//}
//);

@end
