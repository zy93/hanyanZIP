//
//  XLLoginMgr.m
//  pbuXingLianClient
//
//  Created by 1bu2bu on 2017/6/20.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import "XLLoginMgr.h"
#import "BUAFHttpRequest.h"
#import "BUCustomViewController.h"
#import <RongIMKit/RongIMKit.h>
#import "BUCustomViewController.h"
#import "MBProgressHUD.h"
#import "AFHTTPSessionManager.h"



#define WECHAT_PLATFORM_APPID @"wx6968ed6160e33366"
#define WECHAT_PLATFORM_APPSECRET @"3530e5b48a348ff6dfcf9c09f4d71b54"

@interface XLLoginMgr ()<BUAFHttpRequestDelegate>
{
    BUAFHttpRequest *m_pLoginRequest;
    BUAFHttpRequest *m_pAutomaticLoginRequest;
    BUAFHttpRequest *m_pThirdLoginRequest;
    MBProgressHUD *m_pProgressHUD;
    UIAlertView *m_pAlert;
    UIActivityIndicatorView *m_pActivityIndicatorView;
}

@end
@implementation XLLoginMgr

singleton_implementation(XLLoginMgr);

#pragma mark - public methods
- (void)ShowProgressHUDWithMessage:(NSString *)argMessage
{
    m_pActivityIndicatorView = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(0,0,60,60)];
    m_pActivityIndicatorView.center=mAppDelegate.window.center;
    [m_pActivityIndicatorView setActivityIndicatorViewStyle:UIActivityIndicatorViewStyleGray];
    [m_pActivityIndicatorView setActivityIndicatorViewStyle:UIActivityIndicatorViewStyleWhiteLarge];
    [m_pActivityIndicatorView setBackgroundColor:[UIColor colorWithWhite:0 alpha:0.5]];
    [mAppDelegate.window addSubview:m_pActivityIndicatorView];
    [m_pActivityIndicatorView startAnimating];

}


- (void)HideProgressHUD
{
//    dispatch_after( dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5*NSEC_PER_SEC)), dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0), ^{
        [m_pActivityIndicatorView stopAnimating];
//    });
    
}

-(void)LoginRequest:(NSString *)argPhone andPassword:(NSString *)argPassword andType:(NSInteger)argType
{
    m_pLoginRequest = [[BUAFHttpRequest alloc] initWithUrl:@"login.php" andTag:@"login"];
    m_pLoginRequest.propDelegate = self;
    m_pLoginRequest.propDataClass = [XLUserInfoData class];
    [m_pLoginRequest SetParamValue:argPhone forKey:@"mobile"];
    [m_pLoginRequest SetParamValue:argPassword forKey:@"password"];
    [m_pLoginRequest SetParamValue:@"1" forKey:@"device_type"];
    [m_pLoginRequest PostAsynchronous];
    if (argType == 2)
    {
        [self ShowProgressHUDWithMessage:@""];
    }
}

-(void)AutomaticLoginRequest:(NSString *)argUid andPassword:(NSString *)argToken
{
    m_pAutomaticLoginRequest = [[BUAFHttpRequest alloc] initWithUrl:@"autologin.php" andTag:@"autologin"];
    m_pAutomaticLoginRequest.propDelegate = self;
    m_pAutomaticLoginRequest.propDataClass = [XLUserInfoData class];
    [m_pAutomaticLoginRequest SetParamValue:argUid forKey:@"uid"];
    [m_pAutomaticLoginRequest SetParamValue:argToken forKey:@"token"];
    [m_pAutomaticLoginRequest SetParamValue:@"1" forKey:@"device_type"];
    [m_pAutomaticLoginRequest PostAsynchronous];
//    [self ShowProgressHUDWithMessage:@"正在加载...."];
}

-(void)LoginSucceeded:(XLUserInfoData *)argData
{
    [[RCIM sharedRCIM] connectWithToken:argData.yuntoken  success:^(NSString *userId) {
        NSLog(@"登陆成功。当前登录的用户ID：%@", userId);
        [XLLoginMgr sharedXLLoginMgr].propIsLogin = 1;
        [XLLoginMgr sharedXLLoginMgr].propUserData = argData;
        NSData *pData = [NSKeyedArchiver archivedDataWithRootObject:argData];
        
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        [defaults setObject:[pData copy] forKey:@"userData"];
        [defaults setObject:@"1" forKey:@"isLogin"];
        NSString *pLoginType = [defaults objectForKey:@"LoginType"];
        if ((IS_EMPTY_STRING(pLoginType) || [pLoginType integerValue] != [[XLLoginMgr sharedXLLoginMgr].propUserData.loginType integerValue]) && !IS_EMPTY_STRING([XLLoginMgr sharedXLLoginMgr].propUserData.loginType))
        {
            [defaults setObject:[XLLoginMgr sharedXLLoginMgr].propUserData.loginType forKey:@"LoginType"];
            pLoginType = [XLLoginMgr sharedXLLoginMgr].propUserData.loginType;
        }
        [XLLoginMgr sharedXLLoginMgr].propUserData.loginType = pLoginType;
        RCUserInfo *user = [[RCUserInfo alloc] initWithUserId:[XLLoginMgr sharedXLLoginMgr].propUserData.uid
                                                         name:[XLLoginMgr sharedXLLoginMgr].propUserData.userName
                                                     portrait:[XLLoginMgr sharedXLLoginMgr].propUserData.headIcon];
        //        [[RCDataBaseManager shareInstance] insertUserToDB:user];
        [[RCIM sharedRCIM] refreshUserInfoCache:user withUserId:[XLLoginMgr sharedXLLoginMgr].propUserData.uid];
        [RCIM sharedRCIM].currentUserInfo = user;
        [defaults  synchronize];
        [self HideProgressHUD];
        if (self.propDelegate != nil && [self.propDelegate respondsToSelector:@selector(LoginSuccessful)])
        {
            [self.propDelegate LoginSuccessful];
        }
    } error:^(RCConnectErrorCode status)
     {
         [self HideProgressHUD];
         NSLog(@"登陆的错误码为:%ld", (long)status);
         if (status == RC_CONN_ID_REJECT || status == RC_CONN_TOKEN_INCORRECT || status == RC_CONN_NOT_AUTHRORIZED || status == RC_CONN_PACKAGE_NAME_INVALID || status == RC_CONN_APP_BLOCKED_OR_DELETED || status == RC_CONN_USER_BLOCKED || status == RC_CLIENT_NOT_INIT || status == RC_DISCONN_KICK || status == RC_INVALID_ARGUMENT || status == RC_INVALID_PARAMETER)
         {
             if (self.propDelegate != nil && [self.propDelegate respondsToSelector:@selector(LoginFailure)])
             {
                 [self.propDelegate LoginFailure];
             }
         }
    } tokenIncorrect:^{
        //token过期或者不正确。
        //如果设置了token有效期并且token过期，请重新请求您的服务器获取新的token
        //如果没有设置token有效期却提示token错误，请检查您客户端和服务器的appkey是否匹配，还有检查您获取token的流程。
        NSLog(@"token错误");
        [self HideProgressHUD];
        if (self.propDelegate != nil && [self.propDelegate respondsToSelector:@selector(LoginFailure)])
        {
            [self.propDelegate LoginFailure];
        }
    }];
}

-(void)WxLoginRequest:(NSString *)argCode
{
//    if ([XLLoginMgr sharedXLLoginMgr].propWxLogin)
//    {
//        return;
//    }
    NSString *urlString =[NSString stringWithFormat:@"https://api.weixin.qq.com/sns/oauth2/access_token?appid=%@&secret=%@&code=%@&grant_type=authorization_code",WECHAT_PLATFORM_APPID,WECHAT_PLATFORM_APPSECRET,argCode];
    __weak XLLoginMgr *loginVC = self;
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager GET:urlString parameters:nil progress:^(NSProgress * _Nonnull downloadProgress)
     {
         NSLog(@"不知道干啥的");
     } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject){
         
        NSDictionary *dicUserInfo = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
        [loginVC GetUserInfoWithAccessToken:[dicUserInfo objectForKey:@"access_token"] andOpenId:[dicUserInfo objectForKey:@"openid"]];
     } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
         NSLog(@"请求失败");
     }];
}

//wx获取用户信息
-(void)GetUserInfoWithAccessToken:(NSString *)accessToken andOpenId:(NSString *)openId
{
    
    NSString *urlString =[NSString stringWithFormat:@"https://api.weixin.qq.com/sns/userinfo?access_token=%@&openid=%@",accessToken,openId];
    __weak XLLoginMgr *loginVC = self;
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager GET:urlString parameters:nil progress:^(NSProgress * _Nonnull downloadProgress)
     {
         NSLog(@"不知道干啥的");
     } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject){
         
         NSDictionary *dicUserInfo = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
         NSLog(@"%@",dicUserInfo);
         [loginVC ThirdLoginRequest:@"wx" andNickName:[dicUserInfo objectForKey:@"nickname"] andHeadImgUrl:[dicUserInfo objectForKey:@"headimgurl"] andOpenId:openId];
     } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
         NSLog(@"请求失败");
     }];
}

- (void)GetWeiboUserInfoWithAccessToken:(NSString *)accessToken andOpenId:(NSString *)openId
{
    NSString *urlString =[NSString stringWithFormat:
                    @"https://api.weibo.com/2/users/show.json?access_token=%@&uid=%@",accessToken,openId];
    __weak XLLoginMgr *loginVC = self;
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager GET:urlString parameters:nil progress:^(NSProgress * _Nonnull downloadProgress)
     {
         NSLog(@"不知道干啥的");
     } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject){
         
         NSDictionary *dicUserInfo = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
         NSLog(@"%@",dicUserInfo);
         [loginVC ThirdLoginRequest:@"sina" andNickName:[dicUserInfo objectForKey:@"name"] andHeadImgUrl:[dicUserInfo objectForKey:@"avatar_hd"] andOpenId:openId];
     } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
         NSLog(@"请求失败");
     }];
}

-(void)ThirdLoginRequest:(NSString *)argThird andNickName:(NSString *)argNcikName andHeadImgUrl:(NSString *)argHeadImgUrl andOpenId:(NSString *)argOpenId
{
    m_pThirdLoginRequest = [[BUAFHttpRequest alloc] initWithUrl:@"logintre.php" andTag:@"ThirdLogin"];
    [m_pThirdLoginRequest SetParamValue:@"1" forKey:@"type"];
    [m_pThirdLoginRequest SetParamValue:argOpenId forKey:@"openid"];
    [m_pThirdLoginRequest SetParamValue:argThird forKey:@"from"];
    [m_pThirdLoginRequest SetParamValue:argHeadImgUrl forKey:@"headIcon"];
    [m_pThirdLoginRequest SetParamValue:argNcikName forKey:@"nickname"];
    m_pThirdLoginRequest.propDelegate = self;
    m_pThirdLoginRequest.propDataClass = [XLUserInfoData class];
    [m_pThirdLoginRequest PostAsynchronous];
}

#pragma mark - BUAFHttpRequestDelegate methods
-(void)RequestSucceeded:(NSString *)argRequestTag withResponseData:(NSArray *)argData
{
    [self HideProgressHUD];
    if ([argRequestTag isEqualToString:@"login"])
    {
        [self LoginSucceeded:[argData firstObject]];
    }
    if ([argRequestTag isEqualToString:@"autologin"])
    {
        [self LoginSucceeded:[argData firstObject]];
    }
    if ([argRequestTag isEqualToString:@"ThirdLogin"])
    {
        [XLLoginMgr sharedXLLoginMgr].propWxLogin = YES;
        [self LoginSucceeded:[argData firstObject]];
    }
}
- (void)RequestErrorHappened:(BUAFHttpRequest *)argRequest withErrorMsg:(NSString *)argMsg
{
    [self HideProgressHUD];
    [self RequestFailed:argRequest];
}

- (void)RequestFailed:(BUAFHttpRequest *)argRequest
{
    [self HideProgressHUD];
//    if ([argRequest.propRequestTag isEqualToString:@"ThirdLogin"])
//    {
        if (self.propDelegate != nil && [self.propDelegate respondsToSelector:@selector(LoginFailure)])
        {
            [self.propDelegate LoginFailure];
        }
//    }

}
@end
