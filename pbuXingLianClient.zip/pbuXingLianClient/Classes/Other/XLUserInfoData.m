//
//  XLUserInfoData.m
//  pbuXingLianClient
//
//  Created by 1bu2bu on 2017/6/20.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import "XLUserInfoData.h"

@implementation XLUserInfoData

//-(id)init
//{
//    self.uid = 0;
//    self.token = @"4bed7fc0f334eb97bbf6b94c142d2538";
//    return  self;
//}

@end
