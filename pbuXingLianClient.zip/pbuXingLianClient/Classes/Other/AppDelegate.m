//
//  AppDelegate.m
//  pbuXingLianClient
//
//  Created by 1bu2bu on 2017/6/20.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import "AppDelegate.h"
#import "AFTabBarViewController.h"
#import "XLLoginPageController.h"
#import "XLLoginMgr.h"
#import "NSString+MD5.h"
#import "ViewController.h"
//融云
#import <RongIMKit/RongIMKit.h>


@interface AppDelegate ()<RCIMConnectionStatusDelegate,XLLoginMgrDelegate,RCIMReceiveMessageDelegate>
{
    NSData *m_pDeviceToken;
    AFTabBarViewController *m_pMainVC;
    NSString *m_strUid;
    BOOL m_bDisplay;
}
@end

@implementation AppDelegate

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)EnterLoginPage
{
    XLLoginPageController *pLoginVC = [[XLLoginPageController alloc]init];
    UINavigationController *pLoginNavVC = [[UINavigationController alloc]initWithRootViewController:pLoginVC];
    pLoginNavVC.navigationBarHidden = YES;
    [[((UINavigationController *)((UITabBarController *)self.window.rootViewController).selectedViewController) topViewController] presentViewController:pLoginNavVC animated:YES completion:^{
        
    }];
}

-(void)PopView
{
    UINavigationController *pNavigation = (UINavigationController *)self.window.rootViewController;
    [pNavigation popViewControllerAnimated:YES];
}



- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.


    //信鸽
    m_bDisplay = YES;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(LoginSucceed) name:kLoginSucceedNotifity object:nil];

    NSString *pLogin = [[NSUserDefaults standardUserDefaults] objectForKey:@"isLogin"];
    [XLLoginMgr sharedXLLoginMgr].propIsLogin = [pLogin integerValue];
    if ([pLogin integerValue] == 1)
    {
        [[RCIM sharedRCIM] disconnect];
        NSData *pData = [[NSUserDefaults standardUserDefaults] objectForKey:@"userData"];
        [XLLoginMgr sharedXLLoginMgr].propUserData = [NSKeyedUnarchiver unarchiveObjectWithData:pData];
        m_strUid = [XLLoginMgr sharedXLLoginMgr].propUserData.uid;
        [XLLoginMgr sharedXLLoginMgr].propDelegate = self;
        [[XLLoginMgr sharedXLLoginMgr] AutomaticLoginRequest:[XLLoginMgr sharedXLLoginMgr].propUserData.uid andPassword:[XLLoginMgr sharedXLLoginMgr].propUserData.token];
    }else
    {
        [XLLoginMgr sharedXLLoginMgr].propWxLogin = NO;
        m_strUid = @"0";
        [XLLoginMgr sharedXLLoginMgr].propUserData.uid = @"0";
        [XLLoginMgr sharedXLLoginMgr].propUserData.token = @"4bed7fc0f334eb97bbf6b94c142d2538";
    }

    [self EnterMainPage];

    
    //设置融云
    [[RCIM sharedRCIM] initWithAppKey:[AppConfigure GetRongCloudKey]];
    [[RCIM sharedRCIM] setConnectionStatusDelegate:self];
    [RCIM sharedRCIM].enablePersistentUserInfoCache = YES;
    [[RCIM sharedRCIM] setReceiveMessageDelegate:self];


    return YES;
}



#pragma mark - XLLoginMgrDelegate methods
-(void)LoginFailure
{
    [XLLoginMgr sharedXLLoginMgr].propUserData.uid = 0;
    [XLLoginMgr sharedXLLoginMgr].propUserData.token = @"4bed7fc0f334eb97bbf6b94c142d2538";
}


- (void)EnterMainPage
{
    m_pMainVC = [[AFTabBarViewController alloc]init];
    m_pMainVC.propViewControllerClasses = @[[ViewController class]];
    m_pMainVC.propTabBarNormalImages = @[@"tabbar_startv.png"];
    m_pMainVC.propTabBarSelectedImages = @[@"tabbar_startv_select.png"];
    m_pMainVC.propTabBarTitles = @[@"测试"];
    self.window.rootViewController = m_pMainVC;
}

-(void)HiddetnTabBar
{
    [m_pMainVC HideTabBar];
}

-(void)LoginSucceed
{
    NSString *token = [[[[m_pDeviceToken description] stringByReplacingOccurrencesOfString:@"<" withString:@""] stringByReplacingOccurrencesOfString:@">" withString:@""] stringByReplacingOccurrencesOfString:@" " withString:@""];
    [[RCIMClient sharedRCIMClient] setDeviceToken:token];
}


- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    m_pDeviceToken = deviceToken;
    NSString *token = [[[[deviceToken description] stringByReplacingOccurrencesOfString:@"<" withString:@""] stringByReplacingOccurrencesOfString:@">" withString:@""] stringByReplacingOccurrencesOfString:@" " withString:@""];
    [[RCIMClient sharedRCIMClient] setDeviceToken:token];
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

// iOS 9 以上请用这个
- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary *)options
{
    return NO;
}

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
{
    return NO;
}

-(void)Logout
{
    [[RCIM sharedRCIM] disconnect:NO];
    [XLLoginMgr sharedXLLoginMgr].propUserData = nil;
    [XLLoginMgr sharedXLLoginMgr].propUserData.token = @"4bed7fc0f334eb97bbf6b94c142d2538";
    [XLLoginMgr sharedXLLoginMgr].propIsLogin = 0;
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:nil forKey:@"userData"];
    [defaults setObject:@"0" forKey:@"isLogin"];
    [defaults synchronize];
    [self EnterMainPage];
}




@end
