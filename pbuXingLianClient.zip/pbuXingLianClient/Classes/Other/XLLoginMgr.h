//
//  XLLoginMgr.h
//  pbuXingLianClient
//
//  Created by 1bu2bu on 2017/6/20.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Singleton.h"
#import "XLUserInfoData.h"

@protocol XLLoginMgrDelegate <NSObject>

@optional
-(void)LoginSuccessful;

-(void)LoginFailure;

@end

@interface XLLoginMgr : NSObject

singleton_interface(XLLoginMgr);

@property (nonatomic,weak)id<XLLoginMgrDelegate> propDelegate;

@property (nonatomic, strong)XLUserInfoData *propUserData;

@property (nonatomic, assign)NSInteger propIsLogin;

@property (nonatomic, assign)NSInteger propWxLogin;

-(void)LoginRequest:(NSString *)argPhone andPassword:(NSString *)argPassword andType:(NSInteger)argType;

-(void)AutomaticLoginRequest:(NSString *)argUid andPassword:(NSString *)argToken;

-(void)WxLoginRequest:(NSString *)argCode;

- (void)GetWeiboUserInfoWithAccessToken:(NSString *)accessToken andOpenId:(NSString *)openId;

//-(void)VerifyUserInformationOnline;

@end
