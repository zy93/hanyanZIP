//
//  UIImage+Color.m
//  pbuXingLianClient
//
//  Created by Ruixin Wang on 2017/10/8.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import "UIImage+Color.h"

@implementation UIImage (Color)

-(UIImage*) AdaptToNewColor:(UIColor*)argColor
{
    
//    CGRect rect = CGRectMake(0, 0, self.size.width, self.size.height);
//    UIGraphicsBeginImageContextWithOptions(rect.size, NO, self.scale);
//    CGContextRef context = UIGraphicsGetCurrentContext();
//    CGContextClipToMask(context, rect, self.CGImage);
//    CGContextSetFillColorWithColor(context, [argColor CGColor]);
//    CGContextFillRect(context, rect);
//    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
//    UIGraphicsEndImageContext();
    
    
    //We want to keep alpha, set opaque to NO; Use 0.0f for scale to use the scale factor of the device’s main screen.
    UIGraphicsBeginImageContextWithOptions(self.size, NO, 0.0f);
    [argColor setFill];
    CGRect bounds = CGRectMake(0, 0, self.size.width, self.size.height);
    UIRectFill(bounds);
    
    //Draw the tinted image in context
    [self drawInRect:bounds blendMode:kCGBlendModeDestinationIn alpha:1.0f];
    
    UIImage *tintedImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return tintedImage;
    
//    if (self.imageOrientation==UIImageOrientationDownMirrored)
//    {
//        UIImage *flippedImage = [[UIImage alloc] initWithCGImage:tintedImage.CGImage
//                                                           scale:self.scale
//                                                     orientation:UIImageOrientationUp];
//        
//        return flippedImage;
//    }
//    
//    UIImage *flippedImage = [[UIImage alloc] initWithCGImage:tintedImage.CGImage
//                                                       scale:self.scale
//                                                 orientation:UIImageOrientationDownMirrored];//argImage.imageOrientation
//    
//    return flippedImage;
//
}
@end
