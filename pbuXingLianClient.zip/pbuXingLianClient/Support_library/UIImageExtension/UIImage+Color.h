//
//  UIImage+Color.h
//  pbuXingLianClient
//
//  Created by Ruixin Wang on 2017/10/8.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//


#import <UIKit/UIKit.h>

@interface UIImage (Color)

-(UIImage*) AdaptToNewColor:(UIColor*)argColor;
@end
