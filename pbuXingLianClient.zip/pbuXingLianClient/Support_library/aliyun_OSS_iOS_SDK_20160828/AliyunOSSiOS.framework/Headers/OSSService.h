//
//  OSSService.h
//  oss_ios_sdk
//
//  Created by zhouzhuo on 8/20/15.
//  Copyright (c) 2015 aliyun.com. All rights reserved.
//

#import <Foundation/Foundation.h>

#define OSS_IOS_SDK_VERSION 2.5.2

#import "OSSDefine.h"
#import "OSSNetworking.h"
#import "OSSClient.h"
#import "OSSModel.h"
#import "OSSUtil.h"
#import "OSSLog.h"

#import "OSSBolts.h"
