//
//  NSString+MD5.h
//  pbuSymbolTechPaiPaiJing
//
//  Created by 周杰 on 15/7/14.
//  Copyright (c) 2015年 周杰. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (md5)

- (NSString *)md5;

@end
