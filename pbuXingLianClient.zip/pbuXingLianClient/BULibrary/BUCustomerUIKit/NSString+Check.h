//
//  NSString+Check.h
//  pbuLiaoBaGuaIosClient
//
//  Created by   on 15/10/10.
//  Copyright © 2015年  . All rights reserved.
//

#import <Foundation/Foundation.h>


///检查是否全是空格
@interface NSString (Check)

- (BOOL)ContentIsEmpty;

@end
