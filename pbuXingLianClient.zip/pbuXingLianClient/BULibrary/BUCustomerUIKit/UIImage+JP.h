//
//  UIImage+JP.h
//  7.8 -- 截屏
//
//  Created by 李鑫浩 on 15/7/8.
//  Copyright (c) 2015年 app17. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (JP)

+ (instancetype)captureWithView:(UIView *)view;

@end
