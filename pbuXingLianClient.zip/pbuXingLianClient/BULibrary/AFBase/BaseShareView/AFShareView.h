//
//  YLEntranceGuardShardView.h
//  pbuYaLianWuYeClient
//
//  Created by   on 16/6/14.
//  Copyright © 2016年  . All rights reserved.
//

#import <UIKit/UIKit.h>


@interface AFShareView : UIView

@property(nonatomic,strong)UIImage *image;   ///分享出去的图片

@property(nonatomic,copy)NSString *imageUrl;   ///分享出去的图片链接

@property(nonatomic,strong)UIViewController *presentedController;     ///授权跳转控制器

@property(nonatomic,copy)NSString *shareTitle;     ///分享出去的标题

@property(nonatomic,copy)NSString *shareContent;        ///分享出去的文本内容

@property(nonatomic,copy)NSString *shareUrl;         ///分享出去的链接

@property (nonatomic, assign) BOOL proInform;   ///举报

@property (nonatomic, assign) BOOL proGetRedPacket;    ///是否是红包分享

@property (nonatomic, assign) BOOL proTextShare;    ///是否是文本分享

@property(nonatomic,copy)void (^ShareResult)(NSError *error);      ///error为空时即表示分享成功

@property(nonatomic,copy)void (^ActivityInformAction) ();          ///活动举报事件

///注册友盟分享
+ (void)RegistUMShare;

/**
 *  显示分享页面
 */
- (void)ShowShareView;

@end
