//
//  YLEntranceGuardShardView.m
//  pbuYaLianWuYeClient
//
//  Created by   on 16/6/14.
//  Copyright © 2016年  . All rights reserved.
//

#import "AFShareView.h"
#import "AppDelegate.h"
#import "XLLoginMgr.h"
#import "BUAFHttpRequest.h"

#import <UMSocialCore/UMSocialCore.h>
#import "UMSocialWechatHandler.h"
//#import "UMSocialQQHandler.h"
#import "UMSocialSinaHandler.h"

#define UMENG_APPKEY @"56719f7b67e58e19ab002117"

#define WECHAT_PLATFORM_APPID @"wx6968ed6160e33366"
#define WECHAT_PLATFORM_APPSECRET @"3530e5b48a348ff6dfcf9c09f4d71b54"

#define SINA_APPID @"3437246315"
#define SINA_APPSECRET @"631cea573802fee7b72bcafbc3c6ba1e"
#define kRedirectURI @"https://api.weibo.com/oauth2/default.html"

@interface AFShareView ()<BUAFHttpRequestDelegate>
{
    UIImageView *m_pShareView;
    UILabel *m_pTitleLb;
    
    UIButton *m_pWxBtn;
    UIButton *m_pWxFriendCircleBtn;
    UIButton *m_pWeiBoBtn;
    
    BUAFHttpRequest *m_pRequest;
}

@end

@implementation AFShareView

+ (void)RegistUMShare
{
    //打开调试日志
    [[UMSocialManager defaultManager] openLog:YES];
    //设置友盟appkey
    [[UMSocialManager defaultManager] setUmSocialAppkey:UMENG_APPKEY];
    //设置微信的appKey和appSecret
    [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_WechatSession appKey:WECHAT_PLATFORM_APPID appSecret:WECHAT_PLATFORM_APPSECRET redirectURL:@"http://mobile.umeng.com/social"];
    //设置新浪的appKey和appSecret
    [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_Sina appKey:SINA_APPID appSecret:SINA_APPSECRET redirectURL:@"http://sns.whalecloud.com/sina2/callback"];
    //设置QQ的appKey和appSecret
//    [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_QQ appKey:QQ_APPID appSecret:nil redirectURL:@"http://mobile.umeng.com/social"];
}

-(id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:[UIScreen mainScreen].bounds];
    if (self)
    {
        [mAppDelegate.window addSubview:self];
        self.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5f];
        self.hidden = YES;
        [self CreateShareView];
        [self CreateRequest];
    }
    return self;
}

#pragma mark - AddSubviews methods

-(void)CreateRequest
{
    m_pRequest = [[BUAFHttpRequest alloc] initWithUrl:@"shareScore.php" andTag:@"shareScore"];
    [m_pRequest SetParamValue:[XLLoginMgr sharedXLLoginMgr].propUserData.uid forKey:@"uid"];
    [m_pRequest SetParamValue:[XLLoginMgr sharedXLLoginMgr].propUserData.token forKey:@"token"];
    [m_pRequest SetParamValue:@"6" forKey:@"type"];
    m_pRequest.propDelegate = self;
}


-(UIButton*)CreateButton:(UIImage*)argImage withPos:(CGPoint)argPos withTitle:(NSString *)argTitle
{
    UIButton *pShareButton = [UIButton buttonWithType:UIButtonTypeCustom];
    pShareButton.frame = CGRectMake(argPos.x, argPos.y, argImage.size.width,argImage.size.height);
    [pShareButton setImage:argImage forState:UIControlStateNormal];
    [pShareButton addTarget:self action:@selector(ShareClick:) forControlEvents:UIControlEventTouchUpInside];
    [m_pShareView addSubview:pShareButton];
    
    UILabel *pTitleLab = [[UILabel alloc] initWithFrame:CGRectMake(argPos.x - 10*[AppConfigure GetLengthAdaptRate], pShareButton.bottom + 9 *[AppConfigure GetLengthAdaptRate], argImage.size.width + 20*[AppConfigure GetLengthAdaptRate], 15)];
    pTitleLab.text = argTitle;
    pTitleLab.font = [UIFont fontWithName:[AppConfigure RegularFont] size:12.0];
    pTitleLab.textColor = UIColorFromHex(0x555555);
    pTitleLab.textAlignment = NSTextAlignmentCenter;
    [m_pShareView addSubview:pTitleLab];
    
    return pShareButton;
}


-(void)CreateShareView
{
    UIButton *pCancelV = [UIButton buttonWithType:UIButtonTypeCustom];
    pCancelV.frame = CGRectMake(0, 0, self.width, 397 * [AppConfigure GetLengthAdaptRate]);
    [pCancelV addTarget:self action:@selector(ShowShareView) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:pCancelV];
    
    m_pShareView = [[UIImageView alloc] initWithFrame:CGRectMake(15 * [AppConfigure GetLengthAdaptRate], self.height, 345 * [AppConfigure GetLengthAdaptRate], 220 * [AppConfigure GetLengthAdaptRate])];
    m_pShareView.backgroundColor = [UIColor whiteColor];
    m_pShareView.layer.cornerRadius = 10;
    m_pShareView.layer.masksToBounds = YES;
    m_pShareView.userInteractionEnabled = YES;
    [self addSubview:m_pShareView];
    
    m_pTitleLb = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, m_pShareView.frame.size.width, 48 * [AppConfigure GetLengthAdaptRate])];
    m_pTitleLb.text = @"分享到";
    m_pTitleLb.textAlignment = NSTextAlignmentCenter;
    m_pTitleLb.font = [UIFont fontWithName:[AppConfigure RegularFont] size:15];
    m_pTitleLb.textColor = UIColorFromHex(0x333333);
    [m_pShareView addSubview:m_pTitleLb];
    
    UIImageView *pLine = [[UIImageView alloc]initWithFrame:CGRectMake(15 * [AppConfigure GetLengthAdaptRate], m_pTitleLb.bottom , m_pShareView.width - 30 * [AppConfigure GetLengthAdaptRate], 1.0f * [AppConfigure GetLengthAdaptRate])];
    pLine.backgroundColor = UIColorFromHex(0xe1e1e1);
    [m_pShareView addSubview:pLine];
    
    UIImage *pOneImg = [UIImage imageNamed:@"ver_wx_friend.png"];
    UIImage *pTenImg = [UIImage imageNamed:@"ver_wx_friend_circle.png"];
    UIImage *pHundredImg = [UIImage imageNamed:@"ver_wb.png"];

    CGFloat fBtnX = (m_pShareView.width - ((pOneImg.size.width *3) + 158*[AppConfigure GetLengthAdaptRate]))/2;
    m_pWxBtn = [self CreateButton:pOneImg withPos:CGPointMake(fBtnX, m_pTitleLb.bottom + 30*[AppConfigure GetLengthAdaptRate])withTitle:@"微信好友"];
    
    m_pWxFriendCircleBtn = [self CreateButton:pTenImg withPos:CGPointMake(m_pWxBtn.right + 79*[AppConfigure GetLengthAdaptRate], m_pWxBtn.top) withTitle:@"朋友圈"];
    
    m_pWeiBoBtn = [self CreateButton:pHundredImg withPos:CGPointMake(m_pWxFriendCircleBtn.right + 79*[AppConfigure GetLengthAdaptRate], m_pWxBtn.top) withTitle:@"新浪微博"];
    
    UIButton *pCancelButton = [[UIButton alloc] initWithFrame:CGRectMake(0, m_pShareView.height - 50*[AppConfigure GetLengthAdaptRate], m_pShareView.width, 50*[AppConfigure GetLengthAdaptRate])];
    [pCancelButton setBackgroundColor:UIColorFromHex(0xf5f5f5)];
    [pCancelButton setImage:[UIImage imageNamed:@"vertical_close.png"] forState:UIControlStateNormal];
    pCancelButton.titleLabel.font = [UIFont fontWithName:[AppConfigure RegularFont] size:15.0];
    [pCancelButton addTarget:self action:@selector(CancelClick) forControlEvents:UIControlEventTouchUpInside];
    [m_pShareView addSubview:pCancelButton];
}

-(void)CancelClick
{
    [self ShowShareView];
}

- (void)setProInform:(BOOL)proInform
{
    UIButton *pShareBtn = [m_pShareView viewWithTag:1000 + 4];
    UILabel *pTitle = [pShareBtn viewWithTag:1];
    if (proInform)
    {
        [pShareBtn setImage:[UIImage imageNamed:@"share_inform"] forState:UIControlStateNormal];
        pTitle.text = @"举报";
    }
    else
    {
        [pShareBtn setImage:[UIImage imageNamed:@"share_close"] forState:UIControlStateNormal];
        pTitle.text = @"关闭";
    }
}

- (void)setProGetRedPacket:(BOOL)proGetRedPacket
{
    m_pTitleLb.text = @"分享";
    UIButton *pShareBtn = [m_pShareView viewWithTag:1000 + 4];
    pShareBtn.hidden = proGetRedPacket;
    m_pShareView.frame = CGRectMake(15 * [AppConfigure GetLengthAdaptRate], self.height, 345 * [AppConfigure GetLengthAdaptRate], 165 * [AppConfigure GetLengthAdaptRate]);
}

#pragma mark - public methods
-(void)ShowShareView
{
    BOOL bOldStatus = self.hidden;
    CGFloat fAlpha = (bOldStatus == YES) ? 1 : 0;
    CGFloat fyPos = (bOldStatus == YES) ? - (m_pShareView.height + 15 * [AppConfigure GetLengthAdaptRate]): 0;
    self.hidden = NO;
    [UIView animateWithDuration:0.3f
                     animations:^{
                         self.alpha = fAlpha;
                         m_pShareView.transform = CGAffineTransformMakeTranslation(0, fyPos);
                     }
                     completion:^(BOOL finished) {
                         self.hidden = !bOldStatus;
                     }];
}

#pragma mark -- Target method
//点击分享的按钮
-(void)ShareClick:(UIButton *)argBtn
{
   
    UMSocialPlatformType socialPlatformType;
    AFWeak;
    if (argBtn == m_pWxFriendCircleBtn)
    {
        socialPlatformType = UMSocialPlatformType_WechatTimeLine;
    } else if (argBtn == m_pWxBtn)
    {
        socialPlatformType = UMSocialPlatformType_WechatSession;
    } else 
    {
        socialPlatformType = UMSocialPlatformType_Sina;
    }
    UMSocialMessageObject *messageObject = [UMSocialMessageObject messageObject];
    messageObject.text = self.shareTitle;
    
    if (!self.proTextShare)
    {
        UMShareWebpageObject *pMessageObject;
        if (IS_EMPTY_STRING(self.imageUrl))
        {
             pMessageObject = [UMShareWebpageObject shareObjectWithTitle:self.shareTitle descr:self.shareContent thumImage:self.image];
        }else
        {
            pMessageObject = [UMShareWebpageObject shareObjectWithTitle:self.shareTitle descr:self.shareContent thumImage:self.imageUrl];
        }
        pMessageObject.webpageUrl = self.shareUrl;
        messageObject.shareObject = pMessageObject;
    }

    [[UMSocialManager defaultManager] shareToPlatform:socialPlatformType messageObject:messageObject currentViewController:self completion:^(id data, NSError *error) {
        if (error == nil && [XLLoginMgr sharedXLLoginMgr].propIsLogin == 1)
        {
            [m_pRequest PostAsynchronous];
        }
        if (weakSelf.ShareResult) {
            weakSelf.ShareResult(error);
        }
 
    }];
    [self ShowShareView];
}

#pragma mark - BUAFHttpRequestDelegate methods
-(void)RequestSucceeded:(NSString *)argRequestTag withResponseData:(NSArray *)argData
{
    if ([argRequestTag isEqualToString:@"shareScore"])
    {
        NSLog(@"111");
//        if (self.propDeleagte != nil && [self.propDeleagte respondsToSelector:@selector(RequestSuccess:)])
//        {
//            [self.propDeleagte RequestSuccess:m_pData.status];
//        }
    }
}
- (void)RequestErrorHappened:(BUAFHttpRequest *)argRequest withErrorMsg:(NSString *)argMsg
{
    [self RequestFailed:argRequest];
}

- (void)RequestFailed:(BUAFHttpRequest *)argRequest
{
    NSLog(@"请求失败");
}


@end
