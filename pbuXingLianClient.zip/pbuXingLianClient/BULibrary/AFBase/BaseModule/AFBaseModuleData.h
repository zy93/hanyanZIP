//
//  AFBaseModuleData.h
//  pbuYaLianWuYeClient
//
//  Created by  on 16/7/20.
//  Copyright © 2016年 . All rights reserved.
//

#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <objc/message.h>

@interface AFBaseModuleData : NSObject<NSCoding,NSCopying,NSMutableCopying>

@end
