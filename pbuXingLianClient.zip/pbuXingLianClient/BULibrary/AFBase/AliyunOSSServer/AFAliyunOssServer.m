//
//  AFAliyunOssServer.m
//  pbuShiJianQiYueClient
//
//  Created by 1bu2bu on 16/10/28.
//  Copyright © 2016年 1bu2bu. All rights reserved.
//

#import "AFAliyunOssServer.h"
#import "AFAliyunOssServerHelper.h"

NSString * const AccessKey = @"LTAIdORZNbsbe1bh";
NSString * const SecretKey = @"U670MVTeEhVnub3emKwhAMmdVLja0T";
NSString * const endPoint = @"http://oss-cn-beijing.aliyuncs.com";
NSString *const dataUrlPrefix = @"http://xinglian3.oss-cn-beijing.aliyuncs.com";
NSString * const bucketName = @"xinglian3";
NSString * const multipartUploadKey = @"multipartUploadObject";
NSString * pathtype = @"1";

@implementation AFAliyunOssServer

//给图片命名
+ (NSString*)getDateTimeString
{
    NSDateFormatter*formatter;
    NSString*dateString;
    formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"yyyy-MM-dd"];
    dateString = [formatter stringFromDate:[NSDate date]];
    return dateString;
}

+ (NSString*)randomStringWithLength:(int)len
{
    NSString*letters =@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    NSMutableString*randomString = [NSMutableString stringWithCapacity: len];
    for(int i = 0; i < len; i ++)
    {
        [randomString appendFormat:@"%C", [letters characterAtIndex:arc4random_uniform((int)[letters length])]];
    }
    return randomString;
}

+ (NSData *)imageData:(UIImage *)myimage
{
    NSData *data=UIImageJPEGRepresentation(myimage, 1.0);
    if (data.length>100*1024) {
        if (data.length>1024*1024) {//1M以及以上
            data=UIImageJPEGRepresentation(myimage, 0.1);
        }else if (data.length>512*1024) {//0.5M-1M
            data=UIImageJPEGRepresentation(myimage, 0.5);
        }else if (data.length>200*1024) {//0.25M-0.5M
            data=UIImageJPEGRepresentation(myimage, 0.9);
        }
    }
    return data;
}

+ (OSSClient *)getOSSClient
{
    OSSClientConfiguration * conf = [OSSClientConfiguration new];
    conf.maxRetryCount = 3; // 网络请求遇到异常失败后的重试次数
    conf.timeoutIntervalForRequest = 30; // 网络请求的超时时间
    conf.timeoutIntervalForResource = 24 * 60 * 60; // 允许资源传输的最长时间
    
    id<OSSCredentialProvider> credential = [[OSSCustomSignerCredentialProvider alloc] initWithImplementedSigner:^NSString *(NSString *contentToSign, NSError *__autoreleasing *error) {
        // 您需要在这里依照OSS规定的签名算法，实现加签一串字符内容，并把得到的签名传拼接上AccessKeyId后返回
        // 一般实现是，将字符内容post到您的业务服务器，然后返回签名
        // 如果因为某种原因加签失败，描述error信息后，返回nil
        NSString *signature = [OSSUtil calBase64Sha1WithData:contentToSign withSecret:SecretKey]; // 这里是用SDK内的工具函数进行本地加签，建议您通过业务server实现远程加签
        if (signature != nil) {
            *error = nil;
        } else {
            *error = [NSError errorWithDomain:@"自加签失败" code:-1001 userInfo:@{@"error_msg":@"自加签失败"}];
            return nil;
        }
        return [NSString stringWithFormat:@"OSS %@:%@", AccessKey, signature];
    }];
    
    return [[OSSClient alloc] initWithEndpoint:endPoint credentialProvider:credential];
}

//根据type返回oss虚拟路径
+(NSString *)GetPath:(NSString *)argType
{
    NSInteger iType = [argType integerValue];
    NSString *pPath = @"";
    switch (iType)
    {
        case 1:
        pPath = @"user";
        break;
        case 2:
        break;
        case 3:
        break;
        case 4:
        break;
        case 5:
        break;
        case 6:
        break;
        case 7:
        break;
        default:
        break;
    }
    return pPath;
}

//上传单张图片

+ (void)uploadImage:(UIImage*)image progress:(OSSNetworkingUploadProgressBlock)progress success:(void(^)(NSString*url))success failure:(void(^)())failure
{
    OSSPutObjectRequest * put = [OSSPutObjectRequest new];
    put.bucketName = bucketName;
    NSString*fileName = [NSString stringWithFormat:@"%@/%@_%@.png",[AFAliyunOssServer GetPath:pathtype], [AFAliyunOssServer getDateTimeString], [AFAliyunOssServer randomStringWithLength:8]];
    put.objectKey = fileName;
    put.uploadingData = [AFAliyunOssServer imageData:image]; // 直接上传NSData
    
    put.uploadProgress = ^(int64_t bytesSent, int64_t totalByteSent, int64_t totalBytesExpectedToSend) {
        NSLog(@"%lld, %lld, %lld", bytesSent, totalByteSent, totalBytesExpectedToSend);
        if (progress) {
            progress(bytesSent ,totalByteSent ,totalBytesExpectedToSend);
        }
    };
    
    OSSTask * putTask = [[AFAliyunOssServer getOSSClient] putObject:put];
    [putTask continueWithBlock:^id(OSSTask *task) {
        if (!task.error) {
            NSString*url= [NSString stringWithFormat:@"%@/%@",dataUrlPrefix, fileName];
            success(url);
        } else {
            failure();
        }
        return nil;
    }];
    
    
    
    // 可以等待任务完成
    // [putTask waitUntilFinished];
}

//上传多张图片
+ (void)uploadImages:(NSArray*)imageArray progress:(void(^)(CGFloat progress))progress success:(void(^)(NSArray *urls))success failure:(void(^)())failure
{
    NSMutableArray *array = [[NSMutableArray alloc]init];
    __block CGFloat totalProgress = 0.0f;
    __block CGFloat partProgress = 1.0f / [imageArray count];
    __block NSUInteger currentIndex = 0;
    AFAliyunOssServerHelper *uploadHelper = [AFAliyunOssServerHelper sharedUploadHelper];
    __weak typeof(uploadHelper) weakHelper = uploadHelper;
    uploadHelper.singleFailureBlock= ^() {
        failure();
        return;
    };
    uploadHelper.singleSuccessBlock= ^(NSString*url) {
        [array addObject:url];
        totalProgress += partProgress;
        progress(totalProgress);
        currentIndex++;
        if([array count] == [imageArray count]) {
            success([array copy]);
            return;
        }else{
            NSLog(@"---%ld",(unsigned long)currentIndex);
            [AFAliyunOssServer uploadImage:imageArray[currentIndex] progress:nil success:weakHelper.singleSuccessBlock failure:weakHelper.singleFailureBlock];
        }
    };
    [AFAliyunOssServer uploadImage:imageArray[0] progress:nil success:weakHelper.singleSuccessBlock failure:weakHelper.singleFailureBlock];
}

@end
