//
//  AFAliyunOssServer.h
//  pbuShiJianQiYueClient
//
//  Created by 1bu2bu on 16/10/28.
//  Copyright © 2016年 1bu2bu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AliyunOSSiOS/OSSService.h>

@interface AFAliyunOssServer : NSObject

/**
 *上传图片
 *
 *@param image 需要上传的image
 *@param progress 上传进度block
 *@param success 成功block返回url地址
 *@param failure 失败block
 */
+ (void)uploadImage:(UIImage*)image progress:(OSSNetworkingUploadProgressBlock)progress success:(void(^)(NSString*url))success failure:(void(^)())failure;

//上传多张图片,按队列依次上传
+ (void)uploadImages:(NSArray*)imageArray progress:(void(^)(CGFloat progress))progress success:(void(^)(NSArray *urls))success failure:(void(^)())failure;

@end
