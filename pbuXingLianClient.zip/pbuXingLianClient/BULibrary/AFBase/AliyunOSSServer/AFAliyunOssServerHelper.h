//
//  AFAliyunOssServerHelper.h
//  pbuShiJianQiYueClient
//
//  Created by 1bu2bu on 16/10/28.
//  Copyright © 2016年 1bu2bu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AFAliyunOssServerHelper : NSObject


@property(copy,nonatomic)void(^singleSuccessBlock)(NSString*);

@property(copy,nonatomic)void(^singleFailureBlock)();

+ (instancetype)sharedUploadHelper;

@end
