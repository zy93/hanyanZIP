//
//  SXBaseTableView.m
//  pbuShanXiSecurityTrafficClient
//
//  Created by  on 15/12/16.
//  Copyright © 2015年 . All rights reserved.
//

#import "AFBaseTableView.h"

@implementation AFBaseTableView

- (id)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame])
    {
        m_arrData = [NSMutableArray array];
        [self SetupBaseTableView];
    }
    return self;
}

- (void)SetupBaseTableView
{
    m_pBaseTable = [[UITableView alloc]initWithFrame:self.bounds style:UITableViewStylePlain];
    m_pBaseTable.delegate = self;
    m_pBaseTable.dataSource = self;
    m_pBaseTable.backgroundColor = [UIColor clearColor];
    m_pBaseTable.rowHeight = 44;
    m_pBaseTable.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    m_pBaseTable.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self addSubview:m_pBaseTable];
}

- (void)CreatNoDataViewWithFlagText:(NSString *)argText FlagImage:(UIImage *)argImage
{
//    m_pBaseTable.hidden = YES;
    m_pNoDataView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.width, argImage.size.height + 30 * [AppConfigure GetLengthAdaptRate] + SIZE_HEIGHT(14))];
    m_pNoDataView.center = CGPointMake(self.width / 2.0f, 178 * [AppConfigure GetLengthAdaptRate] + m_pNoDataView.height / 2.0f);
    m_pNoDataView.hidden = YES;
    [self addSubview:m_pNoDataView];
    
    UIImageView *pNoDataImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, argImage.size.width, argImage.size.height)];
    pNoDataImageView.center = CGPointMake(self.width / 2.0f, pNoDataImageView.size.height / 2.0f);
    pNoDataImageView.image = argImage;
    [m_pNoDataView addSubview:pNoDataImageView];
    
    UILabel *m_pNoDataFlag = [[UILabel alloc]initWithFrame:CGRectMake(0, pNoDataImageView.bottom + 30 * [AppConfigure GetLengthAdaptRate], self.width, SIZE_HEIGHT(14))];
    m_pNoDataFlag.font = [UIFont systemFontOfSize:14];
    m_pNoDataFlag.textColor = UIColorFromHex(0x999999);
    m_pNoDataFlag.textAlignment = NSTextAlignmentCenter;
    m_pNoDataFlag.text = argText;
    [m_pNoDataView addSubview:m_pNoDataFlag];
}

- (void)SetTableViewData:(NSArray *)argData
{
    if ([m_pBaseTable.mj_header isRefreshing] || m_bHeaderRefresh)
    {
        m_bHeaderRefresh = NO;
        [m_arrData removeAllObjects];
    }
    if (argData.count == 0)
    {
        [m_pBaseTable.mj_footer endRefreshingWithNoMoreData];
    }
    [m_arrData addObjectsFromArray:argData];
    [m_pBaseTable reloadData];
    [self StopRefresh];
    
    if (m_arrData.count <= 0 && m_pNoDataView != nil)
    {
        m_pNoDataView.hidden = NO;
//        m_pBaseTable.hidden = YES;
    }
    else
    {
        m_pNoDataView.hidden = YES;
//        m_pBaseTable.hidden = NO;
    }
    if (m_pBaseTable.hidden && m_pNoDataView.hidden) {
    //    m_pBaseTable.hidden = NO;
    }
}

- (NSArray *)GetTableViewData
{
    return m_arrData;
}

- (BOOL)HadLoadData
{
    if (m_arrData == nil)
    {
        return NO;
    }
    return YES;
}

#pragma mark -- Refresh method
/**
 *  添加下拉刷新事件
 */
- (void)AddRefreshHeader
{
    __weak UITableView *pTableView = m_pBaseTable;
    ///添加刷新事件
    pTableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(StartRefresh)];
    pTableView.mj_header.automaticallyChangeAlpha = YES;
}

/**
 *  添加上拉加载事件
 */
- (void)AddRefreshFooter
{
    __weak UITableView *pTableView = m_pBaseTable;
    MJRefreshBackNormalFooter *footer = [MJRefreshBackNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(AddMoreCommentData)];
    footer.automaticallyHidden = YES;
    pTableView.mj_footer = footer;
}

- (void)StartRefresh
{
    if (m_pBaseTable.mj_footer != nil && [m_pBaseTable.mj_footer isRefreshing])
    {
        [m_pBaseTable.mj_footer endRefreshing];
    }
    if (!m_bHeaderRefresh)
    {
        m_bHeaderRefresh = YES;
        [m_pBaseTable.mj_footer resetNoMoreData];
        if (self.proDelegate != nil && [self.proDelegate respondsToSelector:@selector(RefreshDataWithStartId:)])
        {
            [self.proDelegate RefreshDataWithStartId:1];
        }
    }
}

- (void)AddMoreCommentData
{
    if (m_pBaseTable.mj_header != nil && [m_pBaseTable.mj_header isRefreshing])
    {
        [m_pBaseTable.mj_header endRefreshing];
    }
    m_bHeaderRefresh = NO;
    if (m_arrData.count % 10 == 0 && m_arrData.count / 10 >= 1)
    {
        if (self.proDelegate != nil && [self.proDelegate respondsToSelector:@selector(RefreshDataWithStartId:)])
        {
            [self.proDelegate RefreshDataWithStartId:m_arrData.count / 10 + 1];
        }
    }
    else
    {
        [m_pBaseTable.mj_footer endRefreshingWithNoMoreData];
        [self StopRefresh];
    }
}

- (void)StopRefresh
{
    if (m_pBaseTable.mj_header != nil && [m_pBaseTable.mj_header isRefreshing])
    {
        [m_pBaseTable.mj_header endRefreshing];
    }
    if (m_pBaseTable.mj_footer != nil && [m_pBaseTable.mj_footer isRefreshing])
    {
        [m_pBaseTable.mj_footer endRefreshing];
    }
}

#pragma mark -- UITableViewDatasource method
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 90 * [AppConfigure GetLengthAdaptRate];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
//    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (self.proDelegate != nil && [self.proDelegate respondsToSelector:@selector(PushToNextPage:)])
    {
        if (m_arrData.count <= 0)
        {
             [self.proDelegate PushToNextPage:nil];
        }
        else
        {
             [self.proDelegate PushToNextPage:m_arrData[indexPath.row]];
        }
    }
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [self endEditing:YES];
}

//- (NSArray<UITableViewRowAction *> *)tableView:(UITableView *)tableView editActionsForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    UITableViewRowAction *pDeleteAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleNormal title:@"删除" handler:^(UITableViewRowAction * _Nonnull action, NSIndexPath * _Nonnull indexPath) {
//        
//    }];
//    pDeleteAction.backgroundColor = [UIColor redColor];
//    return @[pDeleteAction];
//}


@end
