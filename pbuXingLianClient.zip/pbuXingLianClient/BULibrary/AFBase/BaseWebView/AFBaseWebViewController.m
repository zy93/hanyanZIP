//
//  BUBaseWebViewController.m
//  pbuYaLianWuYeClient
//
//  Created by  on 16/5/23.
//  Copyright © 2016年 . All rights reserved.
//

#import "AFBaseWebViewController.h"
#import "BUAFHttpRequest.h"
#import "AppConfigure.h"
#import "BUAFHttpRequest.h"
#import <objc/runtime.h>
#import <objc/message.h>
//#import "AFShareView.h"

@interface AFBaseWebViewController () <BUAFHttpRequestDelegate>
{
    UIWebView *m_pBaseWeb;   ///加载广告视图
    BUAFHttpRequest *m_pRequest;
    SEL getterSEL;
}

@end

@implementation AFBaseWebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    m_pNameLabel.text = self.propTitle;
    
    
    m_pBaseWeb = [[UIWebView alloc]initWithFrame:CGRectMake(0, m_pTopBar.bottom, self.view.width, self.view.height - m_pTopBar.bottom)];
    m_pBaseWeb.scalesPageToFit = YES;
    m_pBaseWeb.backgroundColor = [UIColor clearColor];
    m_pBaseWeb.delegate = self;
    [self.view addSubview:m_pBaseWeb];
    
    if (!IS_EMPTY_STRING(self.propOnlineUrl))
    {
        m_pBaseWeb.scalesPageToFit = NO;
        if (![self.propOnlineUrl hasPrefix:@"http://"] && ![self.propOnlineUrl hasPrefix:@"https://"])
        {
            self.propOnlineUrl = [NSString stringWithFormat:@"http://%@",self.propOnlineUrl];
        }
        [m_pBaseWeb loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:self.propOnlineUrl]]];
    }
    else if (!IS_EMPTY_STRING(self.propLocationUrl))
    {
        m_pBaseWeb.scalesPageToFit = NO;
        [m_pBaseWeb loadRequest:[NSURLRequest requestWithURL:[NSURL fileURLWithPath:self.propLocationUrl]]];
    }
    else if (!IS_EMPTY_STRING(self.proRichText))
    {
        m_pBaseWeb.scalesPageToFit = NO;
        [m_pBaseWeb loadHTMLString:self.proRichText baseURL:nil];
    }
    
    if (self.proShowShareBtn)
    {
        UIButton *pMoreBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        pMoreBtn.frame = CGRectMake(self.view.width - 50 - 15 * [AppConfigure GetLengthAdaptRate], [AppConfigure GetYStartPos], 50, 44);
        [pMoreBtn setImage:[UIImage imageNamed:@"activity_detail_ topbar_more"] forState:UIControlStateNormal];
        [pMoreBtn addTarget:self action:@selector(MoreFunctionAction) forControlEvents:UIControlEventTouchUpInside];
        pMoreBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
        [m_pTopBar addSubview:pMoreBtn];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

#pragma mark -- Target method
- (void)MoreFunctionAction
{
//    AFWeak;
//    AFShareView *pShareView = [[AFShareView alloc]init];
//    
//    pShareView.shareTitle = self.propTitle;
//    pShareView.shareContent = self.proShareContent;
//    pShareView.shareUrl = self.propOnlineUrl;
//    pShareView.image = [UIImage imageNamed:@"icon-180"];
//    pShareView.proGetRedPacket = YES;
//    
//    pShareView.ShareResult = ^ (NSError *error){
//        if (error) {
//            [weakSelf ShowHUDWithMessage:@"分享失败"];
//        }else{
//            [weakSelf ShowHUDWithMessage:@"分享成功"];
//        }
//    };
//    [pShareView ShowShareView];
}

#pragma mark -- Public method
- (void)LoadWithRichTextUrl:(NSString *)argUrl DataClass:(Class)argClass GetterSEL:(SEL)argSEL
{
    getterSEL = argSEL;
    [self ShowProgressHUDWithMessage:@"正在加载..."];
    m_pRequest = [[BUAFHttpRequest alloc]initWithUrl:argUrl andTag:@"RichText"];
    m_pRequest.propDataClass = argClass;
    m_pRequest.propDelegate = self;
    [m_pRequest PostAsynchronous];
    
    m_pBaseWeb.scalesPageToFit = NO;
}

#pragma mark -- UIWebViewDelegate
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    [self ShowProgressHUDWithMessage:@"正在加载..."];
    return YES;
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [self HideProgressHUD];
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    [self.view ShowErrorAlertWithError:error SuccessBlock:^(NSInteger buttonIndex) {
        
    }];
    [self HideProgressHUD];
}

#pragma mark -- BUAFHttpRequestDelegate Method
- (void)RequestSucceeded:(NSString *)argRequestTag withResponseData:(NSArray *)argData
{
    if ([argRequestTag isEqualToString:@"RichText"])
    {
        NSObject *data = [argData lastObject];
        NSString *strRichText = ((id (*) (id , SEL))objc_msgSend)(data , getterSEL);
        [m_pBaseWeb loadHTMLString:strRichText baseURL:nil];
    }
}

- (void)RequestErrorHappened:(BUAFHttpRequest *)argRequest withErrorMsg:(NSString *)argMsg
{
    [self RequestFailed:argRequest];
}

- (void)RequestFailed:(BUAFHttpRequest *)argRequest
{
    [self ShowHUDWithMessage:@"加载失败"];
}

@end
