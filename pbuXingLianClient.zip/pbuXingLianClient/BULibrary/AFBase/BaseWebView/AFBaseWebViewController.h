//
//  BUBaseWebViewController.h
//  pbuYaLianWuYeClient
//
//  Created by  on 16/5/23.
//  Copyright © 2016年 . All rights reserved.
//

#import "BUCustomViewController.h"

@interface AFBaseWebViewController : BUCustomViewController<UIWebViewDelegate>

///是否显示分享按钮
@property (nonatomic, assign)BOOL proShowShareBtn;

///分享的文本
@property (nonatomic, copy) NSString *proShareContent;

/**
 *  控制器标题
 */
@property(nonatomic,copy)NSString *propTitle;

/**
 *  网络链接
 */
@property(nonatomic,copy)NSString *propOnlineUrl;

/**
 *  本地链接
 */
@property(nonatomic,copy)NSString *propLocationUrl;

///富文本
@property(nonatomic,copy)NSString *proRichText;

/**
 *   加载富文本
 *
 *   @param argUrl     获取富文本的url
 *   @param argClass     Module类
 *   @param argSEL     Module中属性的getter方法
 */
- (void)LoadWithRichTextUrl:(NSString *)argUrl DataClass:(Class)argClass GetterSEL:(SEL)argSEL;

@end
