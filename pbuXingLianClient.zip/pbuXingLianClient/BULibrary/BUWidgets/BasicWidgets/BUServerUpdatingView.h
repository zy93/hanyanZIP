//
//  BUServerUpdatingView.h
//  pbuXingLianClient
//
//  Created by Ruixin Wang on 2017/11/23.
//  Copyright © 2017年 1bu2bu. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol BUServerUpdatingViewDelegate <NSObject>

-(void)ReloadData;

@end

@interface BUServerUpdatingView : UIView

@property (nonatomic,weak)id<BUServerUpdatingViewDelegate> propDelegate;

@end
