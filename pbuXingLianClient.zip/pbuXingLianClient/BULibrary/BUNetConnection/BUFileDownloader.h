//
//  TSAudioDownloader.h
//  DaoTingTuShuo
//
//  Created by -3 on 14-7-2.
//  Copyright (c) 2014年  MultiMedia Lab. All rights reserved.
//

/*
#import <Foundation/Foundation.h>
#import "ASIHTTPRequest.h"
#import "ASINetworkQueue.h"


@interface BUFileDownloader : NSObject
{
    ASINetworkQueue * m_pDownloadQueue;
}

+ (BUFileDownloader*)GetInstance;

+ (void)ClearInstance;

//- (void)Cleanup;

//发送下载文件请求
-(void)GetFile:(NSArray*)argFileURLs;

-(NSString*)GetCacheFile:(NSString*)argPDFUrl;

-(void)Cancel;
@end

*/
